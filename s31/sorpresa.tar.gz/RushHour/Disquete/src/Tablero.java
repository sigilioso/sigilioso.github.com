
/**
 * Clase que representa el espacio en el cual se mover�n los veh�culos en el transcurso del juego
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class Tablero 
{
    private int[][] _tablero;
    private int _dimension;
    private int[] _salida;
    
    /**
     * Crea una nueva instacia de Tablero
     * @param dimension Dimensi�n del tablero
     * @param fsalida Coordenada correspondiente a la fila de la casilla de salida del juego
     * @param csalida Coordenada correspondiente a la columna de la casilla de salida del juego
     */
    public Tablero(int dimension, int fsalida, int csalida) 
    {
        _dimension = dimension;
        _tablero = new int[_dimension][_dimension];
        _salida = new int[2];
        _salida[0] = fsalida;
        _salida[1] = csalida;
        if(((_salida[0] != (_dimension - 1)) && (_salida[1] != (_dimension - 1)) && (_salida[0] != 0) && (_salida[1] != 0)) || (_salida[0] == _salida[1]) || 
           ((_salida[0] == 0) && (_salida[1] == (_dimension - 1))) || ((_salida[0] == (_dimension - 1)) && (_salida[1] == 0)))
        {
            System.out.println("Posici�n de salida inv�lida, se tomar� por defecto la fila del medio y salida por la derecha");
            if((_dimension % 2) == 0) // si la dimensi�n es par coge la mediana
                _salida[0] = ((_dimension / 2) - 1);
            else // si la dimensi�n es impar coge la mediana y para se le suma 1 a la divisi�n porque se trata de una divisi�n entera
                _salida[0] = (((_dimension / 2) + 1) - 1);
            _salida[1] = (_dimension - 1);
        }
    }
    
    /**
     * Actualiza las casillas correspondientes a un veh�culo con un identificador
     * @param vehiculo Veh�culo cuyas casillas se actualizan en el tablero
     * @param identificador Identificador con el que se actualizan las casillas. Para quitar un veh�culo
     * del tablero valor de identificador ser� cero, para ponerlo �ste ser� el propio identificador del 
     * veh�culo
     */
    public void actualizarVehiculo(Vehiculo vehiculo, int identificador)
    {
        if(vehiculo.getTipo() == 1)
        {
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()] = identificador;
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()+1] = identificador;
        }
        if(vehiculo.getTipo() == 2)
        {
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()] = identificador;
            _tablero[vehiculo.getfInicio()+1][vehiculo.getcInicio()] = identificador;
        }
        if(vehiculo.getTipo() == 3)
        {
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()] = identificador;
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()+1] = identificador;
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()+2] = identificador;
        }
        if(vehiculo.getTipo() == 4)
        {
            _tablero[vehiculo.getfInicio()][vehiculo.getcInicio()] = identificador;
            _tablero[vehiculo.getfInicio()+1][vehiculo.getcInicio()] = identificador;
            _tablero[vehiculo.getfInicio()+2][vehiculo.getcInicio()] = identificador;
        }
    }
    
    /**
     * Muestra una representaci�n del tablero por pantalla. �sta variar� seg�n la dimensi�n, el n�mero de veh�culos en el problema
     * y la posici�n de la salida
     */
    public void mostrar() 
    {
        int filas = 1;
        System.out.print("         ");
        for(int h = 1; h <= _tablero.length; h++) // Dependiendo de la dimensi�n se dejan m�s o menos espacios para que los n�meros cuadren
        { //Imprime los n�meros de las columnas, con los espacios correspondientes
            if(h < 9)
                System.out.print(h + "     ");
            else if(h >= 9)
                System.out.print(h + "    ");
            else if(h >= 99)
                System.out.print(h + "   ");
            else
                System.out.print(h + "  ");
        }
        System.out.println();
        if(_salida[1] == (_dimension - 1)) // Si la salida est� a la derecha
        {
            System.out.println(); // Intro si la salida no est� arriba
            for(int i = 0; i < _tablero.length; i++)
            {
                for(int j = -1; j < _tablero[i].length; j++)
                {
                    if(j == -1) // Dependiendo de la dimensi�n se dejan m�s o menos espacios para que los n�meros cuadren
                    {//Imprime el n�mero de las filas, con los espacios correspondientes
                        if(filas < 10)
                            System.out.print(filas + "     ");
                        else if(filas > 9)
                            System.out.print(filas + "    ");
                        else if(filas > 99)
                            System.out.print(filas + "   ");
                        else
                            System.out.print(filas + "  ");
                        filas++;
                    }
                    else if((_tablero[i][j] <=9) && (_tablero[i][j] >=0))
                    {
                        System.out.print("["+ " " + " " + " " +  _tablero[i][j] + "]");
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("#");
                    }
                    else if((_tablero[i][j] <=99) && (_tablero[i][j] >=10))
                    {
                        System.out.print("["+ " " + " " +_tablero[i][j] + "]");
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("#");
                    }
                    else if((_tablero[i][j] <=999) && (_tablero[i][j] >=100))
                    {
                        System.out.print("["+ " " +_tablero[i][j] + "]");
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("#");
                    }
                    else if((_tablero[i][j] <=9999) && (_tablero[i][j] >=1000))
                    {
                        System.out.print("[" +_tablero[i][j] + "]");
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("#");
                    }
                    else if(_tablero[i][j] == -1)
                    {
                        System.out.print("[<-1>]"); 
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("#");
                    }
                }
                System.out.println();
            }
        }
        else if(_salida[1] == 0) 
        {
            System.out.println(); // Intro si la salida no est� arriba
            for(int i = 0; i < _tablero.length; i++)
            {
                for(int j = -1; j < _tablero[i].length; j++)
                {
                    if(j == -1) // Dependiendo de la dimensi�n se dejan m�s o menos espacios para que los n�meros cuadren
                    {//Imprime el n�mero de las filas, con los espacios correspondientes
                        if(filas < 10)
                            System.out.print(filas + "     ");
                        else if(filas > 9)
                            System.out.print(filas + "    ");
                        else if(filas > 99)
                            System.out.print(filas + "   ");
                        else
                            System.out.print(filas + "  ");
                        filas++;
                    }
                    else if((_tablero[i][j] <=9) && (_tablero[i][j] >=0))
                    {
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("\b#");
                        System.out.print("["+ " " + " " + " " +  _tablero[i][j] + "]");
                    }
                    else if((_tablero[i][j] <=99) && (_tablero[i][j] >=10))
                    {
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("\b#");
                        System.out.print("["+ " " + " " +_tablero[i][j] + "]");
                    }
                    else if((_tablero[i][j] <=999) && (_tablero[i][j] >=100))
                    {
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("\b#");
                        System.out.print("["+ " " +_tablero[i][j] + "]");
                    }
                    else if((_tablero[i][j] <=9999) && (_tablero[i][j] >=1000))
                    {
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("\b#");
                        System.out.print("[" +_tablero[i][j] + "]");
                    }
                    else if(_tablero[i][j] == -1)
                    {
                        if((i == _salida[0]) && (j == _salida[1]))
                            System.out.print("\b#");
                        System.out.print("[<-1>]");
                    }
                }
                System.out.println();
            }
        }
        else if(_salida[0] == 0) //Si la salida est� arriba
        {
            System.out.print("         ");
            for(int i = 1; i <= (_salida[1]); i++)
                System.out.print("      ");
            System.out.println("#");
            for(int i = 0; i < _tablero.length; i++)
            {
                for(int j = -1; j < _tablero[i].length; j++)
                {
                    if(j == -1) // Dependiendo de la dimensi�n se dejan m�s o menos espacios para que los n�meros cuadren
                    {//Imprime el n�mero de las filas, con los espacios correspondientes
                        if(filas < 10)
                            System.out.print(filas + "     ");
                        else if(filas > 9)
                            System.out.print(filas + "    ");
                        else if(filas > 99)
                            System.out.print(filas + "   ");
                        else
                            System.out.print(filas + "  ");
                        filas++;
                    }
                    else if((_tablero[i][j] <=9) && (_tablero[i][j] >=0))
                        System.out.print("["+ " " + " " + " " +  _tablero[i][j] + "]");
                    else if((_tablero[i][j] <=99) && (_tablero[i][j] >=10))
                        System.out.print("["+ " " + " " +_tablero[i][j] + "]");
                    else if((_tablero[i][j] <=999) && (_tablero[i][j] >=100))
                        System.out.print("["+ " " +_tablero[i][j] + "]");
                    else if((_tablero[i][j] <=9999) && (_tablero[i][j] >=1000))
                        System.out.print("[" +_tablero[i][j] + "]");
                    else if(_tablero[i][j] == -1)
                        System.out.print("[<-1>]");
                }
                System.out.println();
            }
        }
        else if(_salida[0] == (_dimension - 1))
        {
            System.out.println(); // Intro si la salida no est� arriba
            for(int i = 0; i < _tablero.length; i++)
            {
                for(int j = -1; j < _tablero[i].length; j++)
                {
                    if(j == -1) // Dependiendo de la dimensi�n se dejan m�s o menos espacios para que los n�meros cuadren
                    { //Imprime el n�mero de las filas, con los espacios correspondientes
                        if(filas < 10)
                            System.out.print(filas + "     ");
                        else if(filas > 9)
                            System.out.print(filas + "    ");
                        else if(filas > 99)
                            System.out.print(filas + "   ");
                        else
                            System.out.print(filas + "  ");
                        filas++;
                    }
                    else if((_tablero[i][j] <=9) && (_tablero[i][j] >=0))
                        System.out.print("["+ " " + " " + " " +  _tablero[i][j] + "]");
                    else if((_tablero[i][j] <=99) && (_tablero[i][j] >=10))
                        System.out.print("["+ " " + " " +_tablero[i][j] + "]");
                    else if((_tablero[i][j] <=999) && (_tablero[i][j] >=100))
                        System.out.print("["+ " " +_tablero[i][j] + "]");
                    else if((_tablero[i][j] <=9999) && (_tablero[i][j] >=1000))
                        System.out.print("[" +_tablero[i][j] + "]");
                    else if(_tablero[i][j] == -1)
                        System.out.print("[<-1>]");
                }
                System.out.println();
            }
            System.out.print("         ");
            for(int i = 1; i <= (_salida[1]); i++) //Si la salida est� abajo
                System.out.print("      ");
            System.out.println("#");
        }
    }
    
    /**
     * Obtiene el cojunto de coordenadas de la posici�n de salida
     * @return Array con las coordenadas de la salida
     */
    public int[] getSalida()
    {
        return _salida;
    }
    
    /**
     * Obtiene la dimensi�n del tablero
     * @return Dimensi�n del tablero
     */
    public int getDimension()
    {
        return _dimension;
    }
    
    /**
     * Obtiene la casilla que corresponde a unas coordenadas determinadas
     * @param fil Coordenada correspondiente a la fila de la casilla que se retornar�
     * @param col Coordenada correspondiente a la columna de la casilla que se retornar�
     * @return Casilla que corresponde a las coordenadas recibidas
     */
    public int getCasilla(int fil, int col)
    {
            return _tablero[fil][col];
    }
    
    /**
     * Comprueba que un veh�culo de tipo uno puede ser a�adido al array
     * @return true si hay sitio disponible, false en caso contrario
     */
    public boolean haySitioUno()
    {
        boolean sitio = false;
        int i = 0, j = 1;
        while(i < _tablero.length && !sitio)
        {
            j = 1;
            while(j < _tablero[i].length && !sitio)
            {
                if((_tablero[i][j-1] == 0) && (_tablero[i][j] == 0))
                    sitio = true;
                j++;
            }
            i++;
        }
        return sitio;
    }
    
    /**
     * Comprueba que un veh�culo de tipo dos puede ser a�adido al array
     * @return true si hay sitio disponible, false en caso contrario
     */
    public boolean haySitioDos()
    {
        boolean sitio = false;
        int i = 1, j = 0;
        while(i < _tablero.length && !sitio)
        {
            j = 0;
            while(j < _tablero[i].length && !sitio)
            {
                if((_tablero[i-1][j] == 0) && (_tablero[i][j] == 0))
                    sitio = true;
                j++;
            }
            i++;
        }
        return sitio;
    }
    
    /**
     * Comprueba que un veh�culo de tipo tres puede ser a�adido al array
     * @return true si hay sitio disponible, false en caso contrario
     */
    public boolean haySitioTres()
    {
        boolean sitio = false;
        int i = 0, j = 2;
        while(i < _tablero.length && !sitio)
        {
            j = 2;
            while(j < _tablero[i].length && !sitio)
            {
                if((_tablero[i][j-2] == 0) && (_tablero[i][j-1] == 0) && (_tablero[i][j] == 0))
                    sitio = true;
                j++;
            }
            i++;
        }
        return sitio;
    }
    
    /**
     * Comprueba que un veh�culo de tipo cuatro puede ser a�adido al array
     * @return true si hay sitio disponible, false en caso contrario
     */
    public boolean haySitioCuatro()
    {
        boolean sitio = false;
        int i = 2, j = 0;
        while(i < _tablero.length && !sitio)
        {
            j = 0;
            while(j < _tablero[i].length && !sitio)
            {
                if((_tablero[i-2][j] == 0) && (_tablero[i-1][j] == 0) && (_tablero[i][j] == 0))
                    sitio = true;
                j++;
            }
            i++;
        }
        return sitio;
    }
}