
/**
 * Clase que sirve para controlar que un dato entero pertenezca a un intervalo
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class NumeroException extends Exception 
{
    private int _maximo; //valor m�ximo del intervalo
    private int _minimo; //valor m�nimo del intervalo
    
    
    /**
     * Crea una nueva instancia de NumeroException
     * @param max N�mero m�ximo permitido
     * @param min N�mero m�nimo permitido
     */
    public NumeroException(int max, int min) 
    {
        _maximo = max;
        _minimo = min;
    }
    
    /**
     * Expresa cu�l ha sido la causa del fallo
     * @return Cadena que muestra el intervalo al que debe pertenecer el entero
     */
    public String toString()
    {
        return ("El valor debe estar entre " + _minimo + " y " + _maximo);
    }
}