
/**
 * Clase que sirve de envoltorio al tipo b�sico boolean para pasarlo por referencia
 * @author Christian Felipe �lvarez
 * @author Sergio Gil Bl�zquez
 */
public class Booleano
{
    private boolean _valor;
    
    /**
     * Crea una nueva instancia de Booleano con valor false
     */
    public Booleano()
    {
        _valor = false;
    }
    
    /**
     * Crea una nueva instancia de Booleano
     * @param valor El valor por defecto del Booleano
     */
    public Booleano(boolean valor)
    {
        _valor = valor;
    }
    
    /**
     * Establece el valor del Booleano
     * @param valor Nuevo valor el Booleano
     */
    public void set(boolean valor)
    {
        _valor = valor;
    }
    
    /**
     * Obtiene el valor del Booleano
     * @return Valor del Booleano
     */
    public boolean get()
    {
        return _valor;
    }
}