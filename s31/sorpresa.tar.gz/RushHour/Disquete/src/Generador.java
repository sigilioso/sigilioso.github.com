
/**
 * Clase principal del programa Generador que contiene el m�todo main
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class Generador
{
    public static void main(String[] args) 
    {
        System.out.println("BIENVENIDO AL GENERADOR DE PARTIDAS DE \"RUSH HOUR\"");
        System.out.println("Para la generaci�n de la partida deber� introducir los datos necesarios");
        System.out.println("Si desea salir de la generacion del problema sin terminar, escriba en cualquier punto del proceso la palabra \"exit\" \nEn ese caso el juego no se guardar�. \n");
        LecturaTeclado leeDatos = new LecturaTeclado();
        Tablero tablero = null;
        Problema problema = null;
        Booleano error = new Booleano();
        boolean automatico = false; // inicializada a false, ya que por defecto se crear� una partida manual
        boolean rojo = true; // inicializada a true, ya que el primer veh�culo a a�adir es el "coche rojo"
        int dimension = 0, fsalida = 0, csalida = 0, tipo = 0, posicion = 0;
        String lectura;
        System.out.print("�Desea construir su juego de forma autom�tica? (con posiciones aleatorias) \nPor defecto: \"no\" (si/no): ");
        lectura = leeDatos.leerLinea();
        if(lectura.equals("exit"))
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        if(lectura.equals("si"))
            automatico = true;
        else if(lectura.equals("no"))
            automatico = false;
        else
        {
            System.out.println("Respuesta no v�lida");
            System.out.println("Se inicia el generador por defecto \n");
            automatico = false;
        }
        System.out.print("Introduzca la dimensi�n del tablero: ");
        lectura = leeDatos.leerLinea();
        if(lectura.equals("exit"))
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        try
        {
            dimension = Integer.parseInt(lectura);
            if((dimension > 1000) || (dimension <= 2)) //Se permiten tableros entre 3x3 y 1000x1000
                throw new NumeroException(1000, 3);
        }
        catch(Exception e)
        {
            dimension = tratarError(e, dimension, 1000, 3); //Se comprueba el dato
        }
        if(dimension == -1)
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        System.out.println("Introduzca la posici�n de salida:");
        System.out.print("Fila: ");
        lectura = leeDatos.leerLinea();
        if(lectura.equals("exit"))
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        try
        {
            fsalida = Integer.parseInt(lectura);
            if((fsalida > dimension) || (fsalida <= 0))
                throw new NumeroException(dimension, 1);
        }
        catch(Exception e)
        {
            fsalida = tratarError(e, fsalida, dimension, 1); //Se comprueba el dato
        }
        if(fsalida == -1)
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        System.out.print("Columna: ");

        lectura = leeDatos.leerLinea();
        if(lectura.equals("exit"))
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        try
        {
            csalida = Integer.parseInt(lectura);
            if((csalida > dimension) || (csalida <= 0))
                throw new NumeroException(dimension, 1);
        }
        catch(Exception e)
        {
            csalida = tratarError(e, csalida, dimension, 1); //Se comprueba el dato
        }
        if(csalida == -1)
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        tablero = new Tablero(dimension, (fsalida - 1), (csalida - 1));
        //Se pasan las coordenadas de la salida restando 1 porque las coordenadas recogidas por teclado no coinciden con las posiciones del array
        int dim = tablero.getDimension();
        Vehiculo[] garaje = new Vehiculo[dim*dim/2];
        int limiteMov = -1;
        System.out.println("Introduzca el limite de movimientos para salir del atasco (0 para no limitar): ");
        lectura = leeDatos.leerLinea();
        if(lectura.equals("exit"))
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        try
        {
            limiteMov = Integer.parseInt(lectura);
        }
        catch(NumberFormatException e)
        {
            System.out.println("Dato incorrecto, se tomar� por defecto una partida sin limitaci�n de movimientos");
            limiteMov = 0;
        }
        if(limiteMov < 0)
        {
            System.out.println("Dato incorrecto, se tomar� por defecto una partida sin limitaci�n de movimientos");
            limiteMov = 0;
        }
        if((tablero.getSalida()[1] == 0) || (tablero.getSalida()[1] == tablero.getDimension() - 1))
            tipo = 1;
        else if((tablero.getSalida()[0] == 0) || (tablero.getSalida()[0] == tablero.getDimension() - 1))
            tipo = 2;
        problema = new Problema(garaje, tablero, limiteMov);
        posicion = datos(automatico, rojo, problema, tablero, tipo, error); //Se crea o genera la posici�n del coche rojo
        if(posicion == -1)
        {
            System.out.println("No ha construido el problema con �xito");
            return; //Se sale del juego
        }
        if((tablero.getSalida()[1] == 0) || (tablero.getSalida()[1] == tablero.getDimension() - 1))//Se coloca el coche rojo
            problema.actualizarGaraje((new Vehiculo(-1, tipo, tablero.getSalida()[0], (posicion - 1))), 0);
        else if((tablero.getSalida()[0] == 0) || (tablero.getSalida()[0] == tablero.getDimension() - 1))
            problema.actualizarGaraje((new Vehiculo(-1, tipo, (posicion - 1), tablero.getSalida()[1])), 0);
        tablero.actualizarVehiculo(problema.getGaraje()[0], problema.getGaraje()[0].getIdentificador());
        problema.incrementarUltimoVehiculo();
        rojo = false;
        String respuesta;
        boolean acabar = false;
        do //Se a�aden veh�culos nuevos mientras el usuario as� lo desee
        {
            error.set(false);
            System.out.println();
            problema.getTablero().mostrar();
            System.out.println();
            if(problema.getGaraje()[1] == null) //Si s�lo est� a�adido el rojo
                System.out.print("�Quiere a�adir un nuevo veh�culo al problema? 1.-Si, 2.-No: ");
            else
                System.out.print("�Qu� desea hacer? 1.-A�adir nuevo veh�culo, 2.-No a�adir m�s veh�culos, 3.-Recolocar el �ltimo veh�culo: ");
            respuesta = leeDatos.leerLinea();
            if(respuesta.equals("exit"))
            {
                System.out.println("No ha construido el problema con �xito");
                return; //Se sale del juego
            }
            if(respuesta.equals("1"))
            {
                String cadDatos;
                boolean fallo = false;
                System.out.println("Introduzca el tipo de veh�culo: ");
                System.out.print("(1.-Coche horizontal, 2.-CocheVertical, 3.-Cami�n horizontal, 4.-Cami�n vertical): ");
                try
                {
                    cadDatos = leeDatos.leerLinea();
                    if(cadDatos.equals("exit"))
                    {
                        System.out.println("No ha construido el problema con �xito");
                        return; //Se sale del juego
                    }
                    tipo = Integer.parseInt(cadDatos);
                    if(tipo < 1 || tipo > 4)
                        throw new NumeroException(4, 1);
                }
                catch(Exception e)
                {
                    System.out.println("Tipo no v�lido, veh�culo no a�adido");
                    fallo = true;
                }
                if(!fallo)
                {
                    posicion = datos(automatico, rojo, problema, tablero, tipo, error); //Se crea o genera la posici�n de un veh�culo
                    if(posicion == -1)
                    {
                        System.out.println("No ha construido el problema con �xito");
                        return; //Se sale del juego
                    }
                }
            }
            else if(respuesta.equals("2"))
                acabar = true;
            else if(respuesta.equals("3") && (problema.getGaraje()[1] != null)) // Se regenera la posicion del ultimo vehiculo a�adido
            {
                problema.decrementarUltimoVehiculo();
                tablero.actualizarVehiculo(problema.getGaraje()[problema.getUltimoVehiculo()], 0);
                posicion = datos(automatico, rojo, problema, tablero, tipo, error);
                if(error.get())//Si no se puede recolocar en la posici�n indicada se vuelve al estado anterior
                {
                    tablero.actualizarVehiculo(problema.getGaraje()[problema.getUltimoVehiculo()], problema.getGaraje()[problema.getUltimoVehiculo()].getIdentificador());
                    problema.incrementarUltimoVehiculo();
                }
                if(posicion == -1)
                {
                    System.out.println("No ha construido el problema con �xito");
                    return; //Se sale del juego
                }
            }
            else
                System.out.println("Respuesta no v�lida");
        }
        while(!acabar);
        //Si se ha construido el problema correctamente se pide el path del fichero donde se guardar�
        System.out.println("Introduzca el fichero donde quiere guardar la partida \n (Si no escribe ninguno no se guardar� el)");
        String fich = leeDatos.leerLinea().trim();
        if(!fich.equals("")) //Si no escribe ning�n nombre no guarda
        {
            problema.guardar(fich);
            System.out.println("Problema construido con �xito");
        }
        else
            System.out.println("Problema no guardado");
    }
    
    /**
     * Corrige los errores que se puedan producir cuando el usuario introduce datos incorrectos
     * @param e Excepci�n que identifica al error
     * @param num Dato que ha producido el error
     * @param numMax Extremo superior de un intervalo de valores permitidos
     * @param numMin Extremo inferior de un intervalo de valores permitidos
     * @return Dato recogido y verificado. -1 en caso de haber decidido salir con "exit"
     */
    private static int tratarError(Exception e, int num, int numMax, int numMin)
    {
        System.out.println("Dato introducido no v�lido");
        System.out.println(e.toString());
        String cadPosicion = null;
        LecturaTeclado leeDatos = new LecturaTeclado();
        boolean fallo = true;
        do
        {
            fallo = false;
            try
            {
                System.out.print("Introduzca un dato v�lido: ");
                cadPosicion = leeDatos.leerLinea();
                if(cadPosicion.equals("exit"))
                {
                    num = -1;
                    fallo = false;
                }
                else
                {
                    num = Integer.parseInt(cadPosicion);
                    if(num < numMin || num > numMax)
                        throw new NumeroException(numMax, numMin);
                }
            }
            catch(Exception e2)
            {
                System.out.println("Dato introducido no v�lido");
                System.out.println(e2.toString());
                fallo = true;
            }
        }
        while(fallo);
        return num;
    }
    
    /**
    * Lee o genera los datos a partir de los cuales se colocan los vehiculos en el tablero
    * @param automatico boolean que valdr� true si el modo del generador es autom�tico y false en caso contrario
    * @param rojo boolean que valdr� true si el vehiculo del que se demandan los datos es el rojo
    * @param problema El problema al cual se a�aden los veh�culos
    * @param tablero El tablero donde si sit�an los veh�culos
    * @param tipo Entero que indica el tipo de veh�culo
    * @return Dato recogido y verificado en el caso de un coche rojo y 0 en el caso de otro veh�culo
    */ 
   private static int datos(boolean automatico, boolean rojo, Problema problema, Tablero tablero, int tipo, Booleano error)
   {
       int posicion = 0; // Se devuelve 0 a los veh�culos que no son el rojo
       int dim = tablero.getDimension();
       LecturaTeclado leeDatos = new LecturaTeclado();
       String lectura;
       if(!automatico && rojo) //Se pide la posici�n del coche rojo
       {
            if((tablero.getSalida()[0] == 0) || (tablero.getSalida()[1] == 0)) // Si la salida esta arriba o a la izquierda
            {
                try
                {   // Se limita la generaci�n de la posici�n a los valores posibles entre 2 y (dim - 1)
                    System.out.println("Introduzca la posici�n del coche rojo (Entre 2 y " + (dim - 1) + ")");
                    lectura = leeDatos.leerLinea();
                    if(lectura.equals("exit"))
                        posicion = -1; // Se devuelve -1 si se recibe "exit"
                    else
                    {
                        posicion = Integer.parseInt(lectura);
                        if((posicion > (dim - 1)) || (posicion <= 1))
                            throw new NumeroException((dim - 1), 2);
                    }
                }
                catch(Exception e)
                {
                    posicion = tratarError(e, posicion, (dim - 1), 2); //Se comprueba el dato
                }
            }
            else // Si la salida esta abajo o a la derecha
            {
                try
                {   // Se limita la generaci�n de la posici�n a los valores posibles entre 1 y (dim - 2)
                    System.out.println("Introduzca la posici�n del coche rojo (Entre 1 y " + (dim - 2) + ")");
                    lectura = leeDatos.leerLinea();
                    if(lectura.equals("exit"))
                        posicion = -1;
                    else
                    {
                        posicion = Integer.parseInt(lectura);
                        if((posicion > (dim - 2)) || (posicion <= 0))
                            throw new NumeroException((dim - 2), 1);
                    }
                }        
                catch(Exception e)
                {
                    posicion = tratarError(e, posicion, (dim - 2), 1); //Se comprueba el dato
                }
            }
       } 
       else if(!automatico && !rojo) //Se pregunta la posici�n de un veh�culo y se coloca en el lugar correspondiente
       {
           String coordenada;
           int fila = 0, columna = 0;
           boolean fallo = false;
           System.out.println("Introduzca la posici�n de inicio del vehiculo:");
           System.out.print("Fila: ");
           coordenada = leeDatos.leerLinea();
           if(coordenada.equals("exit"))
               posicion = -1;
           else
           {
               try
               {
                   fila = Integer.parseInt(coordenada);
                   if((fila > tablero.getDimension()) || (fila <= 0))
                       throw new NumeroException(tablero.getDimension(), 1);
               }
               catch(Exception e)
               {
                   System.out.println("La posici�n es incorrecta, veh�culo no a�adido");
                   fallo = true;
               }
               if(!fallo)
               {
                   System.out.print("Columna: ");
                   coordenada = leeDatos.leerLinea();
                   if(coordenada.equals("exit"))
                       posicion = -1;
                   else
                   {
                       try
                       {
                           columna = Integer.parseInt(coordenada);
                           if((columna > tablero.getDimension()) || (columna <= 0))
                               throw new NumeroException(tablero.getDimension(), 1);
                       }
                       catch(Exception e)
                       {
                           System.out.println("La posici�n es incorrecta, veh�culo no a�adido");
                           fallo = true;
                       }
                       if(!fallo)
                       {
                           if(!problema.agnadirVehiculo(tipo, (fila - 1), (columna - 1)))
                           {
                               error.set(true);
                               System.out.println("La posici�n es incorrecta, veh�culo no a�adido");
                           }
                       }
                   }
               }
           }
       }
       else if(automatico && rojo) //Se genera una posici�n aleatoria para el coche rojo
       {
           if((tablero.getSalida()[0] == 0) || (tablero.getSalida()[1] == 0)) // Si la salida esta arriba o a la izquierda
               posicion = (2 + (int)(Math.random()*(dim - 3))); // Se limita la generaci�n de la posici�n a los valores posibles entre (2 y dim - 1)
           else // Si la salida est� abajo o a la derecha
               posicion = (1 + (int)(Math.random()*(dim - 3))); // Se limita la generaci�n de la posici�n a los valores posibles entre (1 y dim - 2)
       }
       else if(automatico && !rojo) //Se coloca un veh�culo en una posici�n aleatoria
       {
           int fila, columna;
           do
           { // Se comprueba que queda sitio en el tablero para a�adir el veh�culo que se generar�
               if(((tipo == 1) && tablero.haySitioUno()) || 
                  ((tipo == 2) && tablero.haySitioDos()) || 
                  ((tipo == 3) && tablero.haySitioTres()) || 
                  ((tipo == 4) && tablero.haySitioCuatro()))
               {
                   fila = (1 + (int)(Math.random()*dim));
                   columna = (1 + (int)(Math.random()*dim));
               }
               else
               {
                   System.out.println("Este tipo de veh�culo no puede ser generado por falta de espacio en el tablero");
                   break;
               }
           }
           while(!problema.agnadirVehiculo(tipo, (fila - 1), (columna - 1)));
       }
       return posicion;
   }
}