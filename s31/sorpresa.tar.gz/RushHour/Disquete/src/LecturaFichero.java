import java.io.*;

/**
 * Clase que sirve de envoltura a la entrada de datos desde un fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class LecturaFichero
{
    private BufferedReader _lectura;
    
    /**
     * Crea una nueva instancia de LecturaFichero
     * @param nombreFichero Nombre del fichero que va a ser le�do
     * @param fallo Variable de tipo Booleano que permite controlar un error en la lectura
     */
    public LecturaFichero(String nombreFichero, Booleano fallo)
    {
         try
         {
            _lectura = new BufferedReader(new FileReader(nombreFichero));
         }
         catch(FileNotFoundException fnfex)
         {
             System.out.println("Fichero no encontrado");
             fallo.set(true);
         }
    }

    /**
     * Lee una linea
     * @return Cadena con la l�nea le�da
     */
    public String leerLinea()
    {
        String leer = null;
        try
        {
            leer = _lectura.readLine();
        }
        catch(IOException e) 
        { 
            System.out.println("Error en la lectura de la linea"); 
        }
        return leer;
        
    }
    
    /**
     * Cierra el fichero 
     */
    public void cerrar()
    {
        try
        {
            _lectura.close();
        }
        catch(IOException e) 
        { 
            System.out.println("Error al cerrar el fichero"); 
        }
    }
}