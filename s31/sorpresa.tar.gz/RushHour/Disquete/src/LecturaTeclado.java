import java.io.*;

/**
 * Clase que sirve de envoltura a la entrada de datos desde el teclado
 * @author Christian Felipe �lvarez
 * @author Sergio Gil Bl�zquez
 */
public class LecturaTeclado 
{
    private BufferedReader _lectura;
    
    /**
     * Crea una nuva intancia de LecturaTeclado 
     */
    public LecturaTeclado() 
    {
        _lectura = new BufferedReader(new InputStreamReader(System.in));
    }
    
    /**
     * Lee una l�nea desde el teclado
     * @return Cadena con la l�nea le�da
     */
    public String leerLinea()
    {
        String linea = null;
        try
        {
            linea = _lectura.readLine();
        }
        catch(IOException e)
        {
            System.out.println(e.toString());
        }
        return linea;
    }
}