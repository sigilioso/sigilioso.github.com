
/**
 * Clase que representa cada uno de los veh�culos que intervienen en el juego.
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class Vehiculo 
{
    private int _identificador;
    private int _tipo; // 1 coche horizontal, 2 coche vertical, 3 cami�n horizontal, 4 cami�n vertical
    private int[] _posicion; // Se guardan las posiciones de inicio del veh�culo
    private int [][] _movimientos; //Array que guarda los posibles movimientos del veh�culo
    
    /**
     * Crea una nueva instancia de Vehiculo
     * @param identificador Entero que permitir� diferenciar cada veh�culo en un problema determinado. Su valor dependar� de lo siguiente:
     *  -1 para el coche rojo
     *  Para el resto de los veh�culos valores enteros positivos
     * @param tipo Entero que expecifica el tipo de Vehiculo que se instancia, seg�n su valor:
     *  1. Coche horizontal
     *  2. Coche vertical
     *  3. Cami�n horizontal  
     *  4. Cami�n vertical
     * @param fInicio Coordenada correspondiente a la fila de la primera casilla que ocupa el veh�culo en un tablero de un problema determinado
     * @param cInicio Coordenada correspondiente a la columna de la primera casilla que ocupa el veh�culo en un tablero de un problema determinado
     */
    public Vehiculo(int identificador, int tipo, int fInicio, int cInicio) 
    {
        _identificador = identificador;
        _tipo = tipo;
        _posicion = new int[2];
        _posicion[0] = fInicio;
        _posicion[1] = cInicio;
        _movimientos = new int[2][2];
        actualizarMovimientos();
    }
    
    /**
     * Obtiene el Identificador del Veh�culo
     * @return Identificador del veh�culo
     */
    public int getIdentificador()
    {
        return _identificador;
    }
    
    /**
     * Obtiene el Tipo del Veh�culo
     * @return Tipo del veh�culo
     */
    public int getTipo()
    {
        return _tipo;
    }
    
    /**
     * Obtiene la coordenada correspondiente a la fila de la primera casilla que ocupa el veh�culo en un tablero de un problema determinado
     * @return Fila de inicio del veh�culo
     */
    public int getfInicio()
    {
        return _posicion[0];
    }
    
    /**
     * Obtiene la coordenada correspondiente a la columna de la primera casilla que ocupa el veh�culo en un tablero de un problema determinado
     * @return Columna de inicio del veh�culo
     */
    public int getcInicio()
    {
        return _posicion[1];
    }

    /**
     * Realiza, si es posible, un movimiento hacia la derecha actualizando las posiciones del veh�culo y del tablero
     * @param tablero Tablero sobre el que se pretende realizar el movimiento
     * @return true si se ha logrado mover el veh�culo correctamente, false en caso contrario
     */
    public boolean moverDerecha(Tablero tablero)
    {
        if(_movimientos[0][1] < tablero.getDimension()) //Se comprueba que la posici�n de destino est� dentro del tablero
        {
            if(tablero.getCasilla(_movimientos[0][0], _movimientos[0][1]) == 0 ) //Se comprueba que la posici�n de destino no est� ocupada
            {
                tablero.actualizarVehiculo(this, 0);
                _posicion[1]++;
                actualizarMovimientos();
                tablero.actualizarVehiculo(this, _identificador);
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    /**
     * Realiza, si es posible, un movimiento hacia la izquierda actualizando las posiciones del veh�culo y del tablero
     * @param tablero Tablero sobre el que se pretende realizar el movimiento
     * @return true si se ha logrado mover el veh�culo correctamente, false en caso contrario
     */
    public boolean moverIzquierda(Tablero tablero)
    {
        if(_movimientos[1][1] >= 0) //Se comprueba que la posici�n de destino est� dentro del tablero
        {
            if(tablero.getCasilla(_movimientos[1][0], _movimientos[1][1]) == 0 ) //Se comprueba que la posici�n de destino no est� ocupada
            {
                tablero.actualizarVehiculo(this, 0);
                _posicion[1]--;
                actualizarMovimientos();
                tablero.actualizarVehiculo(this, _identificador);
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    /**
     * Realiza, si es posible, un movimiento hacia arriba actualizando las posiciones del veh�culo y del tablero
     * @param tablero Tablero sobre el que se pretende realizar el movimiento
     * @return true si se ha logrado mover el veh�culo correctamente, false en caso contrario
     */
    public boolean moverArriba(Tablero tablero)
    {
        if(_movimientos[1][0] >= 0) //Se comprueba que la posici�n de destino est� dentro del tablero
        {
            if(tablero.getCasilla(_movimientos[1][0], _movimientos[1][1]) == 0 ) //Se comprueba que la posici�n de destino no est� ocupada
            {
                tablero.actualizarVehiculo(this, 0);
                _posicion[0]--;
                actualizarMovimientos();
                tablero.actualizarVehiculo(this, _identificador);
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    /**
     * Realiza, si es posible, un movimiento hacia abajo actualizando las posiciones del veh�culo y del tablero
     * @param tablero Tablero sobre el que se pretende realizar el movimiento
     * @return true si se ha logrado mover el veh�culo correctamente, false en caso contrario
     */
    public boolean moverAbajo(Tablero tablero)
    {
        if(_movimientos[0][0] < tablero.getDimension()) //Se comprueba que la posici�n de destino est� dentro del tablero
        {
            if(tablero.getCasilla(_movimientos[0][0], _movimientos[0][1]) == 0 ) //Se comprueba que la posici�n de destino no est� ocupada
            {
                tablero.actualizarVehiculo(this, 0);
                _posicion[0]++;
                actualizarMovimientos();
                tablero.actualizarVehiculo(this, _identificador);
                return true;
            }
            else
                return false;
        }
        else
            return false;
    }
    
    /**
     * Actualiza el array de movimientos con las coordenadas correspondientes a las casillas anterior y posterior al veh�culo,
     * permitiendo conocer a priori su estado en un tablero determinado.
     */
    public void actualizarMovimientos()
    {
        if(_tipo == 1)
        {
            _movimientos[0][0] = _posicion[0];
            _movimientos[0][1] = _posicion[1] + 2;
            _movimientos[1][0] = _posicion[0];
            _movimientos[1][1] = _posicion[1] - 1;
        }
        if(_tipo == 2)
        {
            _movimientos[0][0] = _posicion[0] + 2;
            _movimientos[0][1] = _posicion[1];
            _movimientos[1][0] = _posicion[0] - 1;
            _movimientos[1][1] = _posicion[1];
        }
        if(_tipo == 3)
        {
            _movimientos[0][0] = _posicion[0];
            _movimientos[0][1] = _posicion[1] + 3;
            _movimientos[1][0] = _posicion[0];
            _movimientos[1][1] = _posicion[1] - 1;
        }
        if(_tipo == 4)
        {
            _movimientos[0][0] = _posicion[0] + 3;
            _movimientos[0][1] = _posicion[1];
            _movimientos[1][0] = _posicion[0] - 1;
            _movimientos[1][1] = _posicion[1];
        }
    }
}