import java.util.*;

/**
 * Clase que representa un problema de Rush Hour
 * @author Christian Felipe �lvarez
 * @author Sergio Gil Bl�zquez
 */
public class Problema
{
    private Vehiculo[] _garaje; //el coche rojo se guarda en 0, el resto veh�culos en la de su identificador
    private int _ultimoVehiculo; //posici�n en el array e identificador del �ltimo veh�culo a�adido
    private Tablero _tablero; //tablero en el que se sit�an los veh�culos
    private int _limiteMov; //posibilidad de limitar el n�mero de movimientos, 0 para no limitar
    private int _numeroMov; //movimientos que se han realizado en el procedimiento de un juego
    private String _fichero; //ruta del fichero desde el que se carga un problema
    
    /** 
     * Crea una nueva instacia de Problema a partir de datos externos
     * @param garaje Array con todos los veh�culos del juego
     * @param tablero Tablero en el que se representa el juego
     * @param limiteMov N�mero l�mite de movimientos para alcanzar la soluci�n en el problema
     */
    public Problema(Vehiculo[] garaje,  Tablero tablero, int limiteMov)
    {
        _tablero = tablero;
        _garaje = garaje;
        _ultimoVehiculo = 0;
        _limiteMov = limiteMov;
        _numeroMov = 0;
        _fichero = null;
    }
    
    /**
     * Crea una nueva instancia de Problema
     */
    public Problema()
    {
        
    }
    
     /** 
      * Carga las propiedades de un problema a partir de datos le�dos en un fichero 
      * @param fich Cadena con el path del fichero
      * @param fallo Variable de tipo Booleano que permite controlar un fallo en caso de lectura err�nea de fichero
      */
    public void cargar(String fich, Booleano fallo)
    {
        _fichero = fich;
        LecturaFichero carga = new LecturaFichero(_fichero, fallo);
        if(!fallo.get())
        {
            try
            {
                StringTokenizer linea1 = new StringTokenizer(carga.leerLinea().trim(), ","); //lectura de la primera l�nea, con las propiedades del tablero
                _tablero = new Tablero(Integer.parseInt(linea1.nextToken()), Integer.parseInt(linea1.nextToken()), Integer.parseInt(linea1.nextToken()));
                StringTokenizer linea2 = new StringTokenizer(carga.leerLinea().trim(), ","); //lectura de la segunda l�nea con el contador y limitador de movimientos
                _limiteMov = Integer.parseInt(linea2.nextToken());
                _numeroMov = Integer.parseInt(linea2.nextToken());
                _ultimoVehiculo = Integer.parseInt(linea2.nextToken()); 
                _garaje = new Vehiculo[_tablero.getDimension()*_tablero.getDimension()/2];
                StringTokenizer linea3 = new StringTokenizer(carga.leerLinea().trim(), ","); //lectura de la tercera l�nea con la informaci�n del rojo
                _garaje[0] = new Vehiculo(Integer.parseInt(linea3.nextToken()), Integer.parseInt(linea3.nextToken()), Integer.parseInt(linea3.nextToken()), Integer.parseInt(linea3.nextToken()));
                _tablero.actualizarVehiculo(_garaje[0], _garaje[0].getIdentificador());
                for(int i = 1; i < _ultimoVehiculo; i++)
                {
                    StringTokenizer linea = new StringTokenizer(carga.leerLinea().trim(), ","); //lectura de la tercera l�nea con la informaci�n del vehiculo i
                    _garaje[i] = new Vehiculo(Integer.parseInt(linea.nextToken()), Integer.parseInt(linea.nextToken()), Integer.parseInt(linea.nextToken()), Integer.parseInt(linea.nextToken()));
                    _tablero.actualizarVehiculo(_garaje[i], _garaje[i].getIdentificador());
                }
                carga.cerrar();
            }
            catch(NumberFormatException e)
            {
                fallo.set(true);
            }
            catch(NoSuchElementException e) //Salta si faltan elementos en la lectura
            {
                fallo.set(true);
            }
        }
    }

    /**
     * A�ade un nuevo Vehiculo al problema
     * @param tipo Tipo del veh�culo que se va a a�adir
     * @param fila Posici�n inicial del veh�culo
     * @param columna Posici�n inicial del veh�culo
     * @return true si se a�ade el veh�culo correctamente, false en caso contrario
     */
    public boolean agnadirVehiculo(int tipo, int fila, int columna)
    {
        if((tipo == 1) && (columna+1 < _tablero.getDimension()) && (_tablero.getCasilla(fila, columna) == 0) && (_tablero.getCasilla(fila, columna+1) == 0))
        {
            _garaje[_ultimoVehiculo] = new Vehiculo(_ultimoVehiculo, 1, fila, columna);
            _tablero.actualizarVehiculo(_garaje[_ultimoVehiculo], _garaje[_ultimoVehiculo].getIdentificador());
            _ultimoVehiculo++;
            return true;
        } 
        else if((tipo == 2) && (fila+1 < _tablero.getDimension()) && (_tablero.getCasilla(fila, columna) == 0) && (_tablero.getCasilla(fila+1, columna) == 0))
        {
            _garaje[_ultimoVehiculo] = new Vehiculo(_ultimoVehiculo, 2, fila, columna);
            _tablero.actualizarVehiculo(_garaje[_ultimoVehiculo], _garaje[_ultimoVehiculo].getIdentificador());
            _ultimoVehiculo++;
            return true;
        }   
        else if((tipo == 3) && (columna+2 < _tablero.getDimension()) && (_tablero.getCasilla(fila, columna) == 0) && (_tablero.getCasilla(fila, columna+1) == 0) && (_tablero.getCasilla(fila, columna+2) == 0))
        {
            _garaje[_ultimoVehiculo] = new Vehiculo(_ultimoVehiculo, 3, fila, columna);
            _tablero.actualizarVehiculo(_garaje[_ultimoVehiculo], _garaje[_ultimoVehiculo].getIdentificador());
            _ultimoVehiculo++;
            return true;
        }
        else if((tipo == 4) && (fila+2 < _tablero.getDimension()) && (_tablero.getCasilla(fila, columna) == 0) && (_tablero.getCasilla(fila+1, columna) == 0) && (_tablero.getCasilla(fila+2, columna) == 0))
        {
            _garaje[_ultimoVehiculo] = new Vehiculo(_ultimoVehiculo, 4, fila, columna);
            _tablero.actualizarVehiculo(_garaje[_ultimoVehiculo], _garaje[_ultimoVehiculo].getIdentificador());
            _ultimoVehiculo++;
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Guarda el problema en un fichero codificado de la forma siguiente:
     * Las tres cifras separadas por comas de la primera l�nea corresponden a la dimensi�n, la fila de la salida y la columna de la salida respectivamente.
     * Las tres cifras separadas por comas de la segunda l�nea corresponden al l�mite de movimientos, el n�mero de movimientos realizados y el identificador de veh�culo que ir�a a continuaci�n del �ltimo del problema.
     * Las cuatro cifras separadas por comas del resto de las l�neas corresponden a las propiedades de los veh�culos: al identificador, tipo y a la fila y columna de inicio respectivamente, correspondiendo la tercera l�nea al coche rojo.
     * @param fich Nombre del fichero donde se guardar� el problema
     */
    public void guardar(String fich)
    {
        if(fich.indexOf(".rush") != -1)
            fich = fich.substring(0 , fich.indexOf(".rush"));
        EscrituraFichero escritura = new EscrituraFichero(fich + ".rush"); //Se a�ade la extensi�n (".rush") al nombre del fichero para una mejor identificaci�n
        escritura.println(_tablero.getDimension() + "," + _tablero.getSalida()[0] + "," + _tablero.getSalida()[1]);
        escritura.println(_limiteMov + "," + _numeroMov + "," + _ultimoVehiculo);
        for(int i = 0; i <_ultimoVehiculo; i++)
            escritura.println(_garaje[i].getIdentificador() + "," + _garaje[i].getTipo() + "," + _garaje[i].getfInicio() + "," + _garaje[i].getcInicio());
        escritura.cerrar();
        System.out.println("Fichero guardado");
    }
    
    /**
     * Comprueba si se ha alcanzado la soluci�n al problema
     * @return true si ha sido alcanzada, false en caso contrario
     */
    public boolean solucionAlcanzada()
    {
        if((_garaje[0].getcInicio() == (_tablero.getDimension() - 1)) && (_tablero.getSalida()[1] == (_tablero.getDimension() - 1)) || 
           (_garaje[0].getfInicio() == (_tablero.getDimension() - 1)) && (_tablero.getSalida()[0] == (_tablero.getDimension() - 1)) ||
           (_garaje[0].getcInicio() == 0) && (_tablero.getSalida()[1] == 0) ||
           (_garaje[0].getfInicio() == 0) && (_tablero.getSalida()[0] == 0))
            return true;
        else
            return false;
    }
    
    /**
     * Obtiene el n�mero de movimientos
     * @return N�mero de movimientos acumulados
     */
    public int getNumeroMovimientos()
    {
        return _numeroMov;
    }
    
    /**
     * Obtiene el n�mero de movimientos l�mite
     * @return Numero l�mite de movimientos
     */
    public int getLimiteMovimientos()
    {
        return _limiteMov;
    }
    
    /**
     * Decrementa el n�mero de movimientos disponibles
     */
    public void decrementarLimiteMovimientos()
    {
        _limiteMov--;
    }
    
     /**
     * Incrementa el n�mero de movimientos
     */
    public void incrementarNumeroMov()
    {
        _numeroMov++;
    }
    
    /**
     * Obtiene el tablero
     * @return Tablero
     */
    public Tablero getTablero()
    {
        return _tablero;
    }
    
    /**
     * Obtiene la primera posici�n libre en el garaje
     * @return Primera posici�n libre en el garaje
     */
    public int getUltimoVehiculo()
    {
        return _ultimoVehiculo;
    }
    
    /**
     * Obtiene el path de un fichero cargado
     * @return Path del fichero cargado
     */
    public String getFichero()
    {
        return _fichero;
    }
    
    /**
     * Obtiene un array con los veh�culos que pertenecen al problema
     * @return Array con todos los veh�culos
     */
    public Vehiculo[] getGaraje()
    {
        return _garaje;
    }
    
    /**
     * Obtiene el veh�culo correspondiente a un identificador
     * @param identificador Identificador del veh�culo que se obtendr�
     * @return Veh�culo correspondiente al identificador
     */
    public Vehiculo getVehiculo(int identificador)
    {
        if(identificador == -1)
            return _garaje[0];
        else
            return _garaje[identificador];       
    }
    
    /**
     * Guarda un veh�culo en el problema
     * @param vehiculo Veh�culo que se va a guardar en el problema
     * @param posicion Posicion del veh�culo en el problema
     */
    public void actualizarGaraje(Vehiculo vehiculo, int posicion)
    {
        _garaje[posicion] = vehiculo;
    }
    
    /**
     * Incrementa en uno el �ltimo veh�culo
     */
    public void incrementarUltimoVehiculo()
    {
        _ultimoVehiculo++;
    }
    
     /**
     * Decrementa en uno el �ltimo veh�culo
     */
    public void decrementarUltimoVehiculo()
    {
        _ultimoVehiculo--;
    }
}