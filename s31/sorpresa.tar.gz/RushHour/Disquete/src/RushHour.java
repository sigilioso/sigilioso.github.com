
/**
 * Clase principal del programa RushHour que contiene el m�todo main
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class RushHour
{
    public static void main(String[] args)
    {
        LecturaTeclado leer = new LecturaTeclado();
        Booleano salida = new Booleano();
        Booleano jugar = new Booleano();
        Booleano fallo = new Booleano();
        System.out.println("BIENVENIDO AL JUEGO \"RUSH HOUR\" \n");
        Problema problema = new Problema();
        problema.cargar(obtenerRuta(), fallo);
        if(fallo.get())//Si no encuentra el fichero, sale del juego
        {
            System.out.println("Se ha producido alg�n error al leer el fichero");
            System.out.println("�Adi�s!");
            return;
        }
        do
        {
            while((salida.get() == false) && (jugar.get() == false))
            {
                System.out.println();
                problema.getTablero().mostrar();
                System.out.println();
		    if(problema.getLimiteMovimientos() != 0)
 	                System.out.println("En esta partida lleva acumulados " + problema.getNumeroMovimientos() + " movimientos y tiene un l�mite de " + problema.getLimiteMovimientos() + " movimientos.");
		    else
			System.out.println("En esta partida lleva acumulados " + problema.getNumeroMovimientos() + " movimientos"); 
                System.out.println("�Qu� desea hacer a continuaci�n?");
                opcionMenu(0, salida, jugar, fallo, problema); //Se va al men� correspondiente
            }
            if(salida.get() == true) //Se sale del juego
                break;  
            System.out.println();
            System.out.println("Recuerde que puede salir en cualquier momento de la partida escribiendo la palabra \"exit\"");
            do
            {
                if(problema.getLimiteMovimientos() != 0)
                    System.out.println("Le quedan " + (problema.getLimiteMovimientos() - problema.getNumeroMovimientos()) + " movimientos para poder solucionar el problema");
                int vehiculo = 0;
                String cadVehiculo = null;
                System.out.println();
                problema.getTablero().mostrar();
                System.out.println();
                System.out.print("�Qu� veh�culo quiere mover? ");
                boolean falloJuego = false;
                try //Se recoge el dato introducido por el usuario
                {
                    cadVehiculo = leer.leerLinea();
                    vehiculo = Integer.parseInt(cadVehiculo);
                    if((vehiculo >= problema.getUltimoVehiculo()) || (vehiculo < -1) || (vehiculo == 0))
                        throw new NumeroException(problema.getUltimoVehiculo(), -1);
                }
                catch(NumberFormatException e)
                {
                    if(cadVehiculo.equals("exit"))
                        break; //Se sale del juego
                    System.out.println("Dato introducido no v�lido");
                    falloJuego = true;
                }
                catch(NumeroException e)
                {
                    System.out.println("No hay ning�n veh�culo con ese identificador");
                    falloJuego = true;
                }
                if(!falloJuego)
                {
                    int mov = 0;
                    String cadmov = null;
                    if((problema.getVehiculo(vehiculo).getTipo() == 1) || (problema.getVehiculo(vehiculo).getTipo() == 3) )
                    {
                        System.out.print("1.-Izquierda, 2.-Derecha : ");
                        try
                        { //Se recoge el dato introducido por el usuario
                            cadmov = leer.leerLinea();
                            mov = Integer.parseInt(cadmov);
                        }
                        catch(NumberFormatException e)
                        {
                            if(cadmov.equals("exit"))
                                break;  //Se sale del juego
                            System.out.println("Movimiento no reconocido");
                            falloJuego = true;
                        }
                        if((mov != 1) && (mov != 2) && (!falloJuego))
                        {
                            System.out.println("Movimiento no reconocido");
                            falloJuego = true;
                        }
                        else
                        {
                            if(mov == 1)
                            {
                                if(!problema.getVehiculo(vehiculo).moverIzquierda(problema.getTablero()))
                                    System.out.println("No se puede realizar el movimiento seleccionado");
                                else
                                    problema.incrementarNumeroMov();
                            }
                            else if(mov == 2)
                            {
                                if(!problema.getVehiculo(vehiculo).moverDerecha(problema.getTablero()))
                                    System.out.println("No se puede realizar el movimiento seleccionado");
                                else
                                    problema.incrementarNumeroMov();
                            }
                        }
                    }
                    else if((problema.getVehiculo(vehiculo).getTipo() == 2) || (problema.getVehiculo(vehiculo).getTipo() == 4))
                    {
                        System.out.print("1.-Arriba, 2.-Abajo : ");
                        try //Se recoge el dato introducido por el usuario
                        {
                            cadmov = leer.leerLinea();
                            mov = Integer.parseInt(cadmov);
                        }
                        catch(NumberFormatException e)
                        {
                            if(cadmov.equals("exit"))
                                break;  //Se sale del juego
                            System.out.println("Movimiento no reconocido");
                            falloJuego = true;
                        }
                        if((mov != 1) && (mov != 2) && (!falloJuego))
                        {
                            System.out.println("Movimiento no reconocido");
                            falloJuego = true;
                        }
                        else
                        {
                            if(mov == 1)
                            {
                                if(!problema.getVehiculo(vehiculo).moverArriba(problema.getTablero()))
                                    System.out.println("No se puede realizar el movimiento seleccionado");
                                else
                                    problema.incrementarNumeroMov();
                            }
                            else if(mov == 2)
                            {
                                if(!problema.getVehiculo(vehiculo).moverAbajo(problema.getTablero()))
                                    System.out.println("No se puede realizar el movimiento seleccionado");
                                else
                                    problema.incrementarNumeroMov();
                            }
                        }
                    }
                }
            } //Mientras no haya logrado solucionar el problema y no se haya alcanzado el l�mite de movimientos en el caso que se limite
            while(!problema.solucionAlcanzada() && ((problema.getLimiteMovimientos() > problema.getNumeroMovimientos()) || (problema.getLimiteMovimientos() == 0)));
            if(problema.solucionAlcanzada())
            {
                System.out.println();
                problema.getTablero().mostrar();
                System.out.println();
                System.out.println("Soluci�n encontrada. ��ENHORABUENA!!");
                System.out.println("Ha necesitado " + problema.getNumeroMovimientos() + " movimientos para solucionar el problema");
                opcionMenu(-1, salida, jugar, fallo, problema);  //Se va al men� correspondiente
            }
            else if(problema.getLimiteMovimientos() == problema.getNumeroMovimientos())
            { 
                System.out.println();
                problema.getTablero().mostrar();
                System.out.println();
                System.out.println("Se le terminaron las oportunidades, no pudo dar con la soluci�n");
                opcionMenu(-1, salida, jugar, fallo, problema);  //Se va al men� correspondiente
            }
            else
                opcionMenu(1, salida, jugar, fallo, problema);  //Se va al men� correspondiente
        }
        while(salida.get() == false);
    }
    
    /**
     * Obtiene el path del fichero a cargar le�do desde teclado
     * @return Cadena con el path del fichero
     */
    public static String obtenerRuta()
    {
        LecturaTeclado leerNombre = new LecturaTeclado();
        System.out.println("Introduzca el fichero que quiere cargar: ");
        return leerNombre.leerLinea();
    }
    
    /**
     * Muestra los distintos tipos de men�s y lee la opci�n que elija el usuario
     * @param menu Tipo del men� que se mostrar�
     * @return Opci�n elegida por el usuario, o -2 si no es una opci�n v�lida
     */
    public static int menu(int menu)
    {
        LecturaTeclado leerOpcion = new LecturaTeclado();
        int eleccion = 0;
        if(menu == 0)
        {
            System.out.println();
            System.out.println("1.- Jugar partida");
            System.out.println("2.- Cargar otra partida");
            System.out.println("3.- Salir del juego");
            System.out.println();
        }
        else if(menu == 1)
        {
            System.out.println();
            System.out.println("1.- Continuar partida");
            System.out.println("2.- Reiniciar partida");
            System.out.println("3.- Cargar otra partida");
            System.out.println("4.- Guardar partida actual");
            System.out.println("5.- Guardar partida actual como...");
            System.out.println("6.- Salir del juego");
            System.out.println();
                
        }
        else
        {
            System.out.println();
            System.out.println("1.- Reiniciar partida");
            System.out.println("2.- Cargar otra partida");
            System.out.println("3.- Salir del juego");
            System.out.println();
        }
        try
        {
            System.out.print("Seleccione una opci�n: ");
            eleccion = Integer.parseInt(leerOpcion.leerLinea());
        }
        catch(NumberFormatException e)
        {
            eleccion = -2;
        }
        return eleccion;
    }
    
    /**
     * Realiza las operaciones correspondientes a la opci�n seleccionada en cada men�
     * @param tipoMenu Tipo de men� del que se selecciona la opci�n
     * @param salida Variable de tipo Booleano que controla que el usuario quiera salir del juego
     * @param jugar Variable de tipo Booleano que controla que el usuario quiera jugar una partida
     * @param error Variable de tipo Booleano que controla los errores respecto a la carga del juego
     * @param problema Problema sobre el que se opera
     */
    public static void opcionMenu(int tipoMenu, Booleano salida, Booleano jugar, Booleano error, Problema problema)
    {
        boolean repetirMenu = false;
        boolean guardado = false;
        int eleccion = 0;
        do
        {
            eleccion = menu(tipoMenu);
            if(tipoMenu == 0)
            {
                switch(eleccion)
                {
                    case 1:
                    {
                        System.out.println("Comencemos a jugar");
                        salida.set(false);
                        jugar.set(true);
                        repetirMenu = false;
                        break;
                    }
                    case 2:
                    {
                        problema.cargar(obtenerRuta(), error);
                        salida.set(false);
                        jugar.set(false);
                        if(error.get())
                        {
                            repetirMenu = true;
                            System.out.println("Error al cargar la partida");
                        }
                        else
                            repetirMenu = false;
                        break;
                    }
                    case 3:
                    {
                        System.out.println("�Adi�s!");
                        salida.set(true);
                        jugar.set(false);
                        repetirMenu = false;
                        break;
                    }
                    default:
                    {
                        System.out.println("Elecci�n incorrecta");
                        repetirMenu = true;
                    }
                }
            }
            else if(tipoMenu == 1)
            {
                switch(eleccion)
                {
                    case 1:
                    {
                        System.out.println("Continuemos jugando");
                        salida.set(false);
                        jugar.set(true);
                        repetirMenu = false;
                        guardado = false;
                        break;
                    }
                    case 2:
                    {
                        problema.cargar(problema.getFichero(), error);
                        salida.set(false);
                        jugar.set(false);
                        if(error.get())
                        {
                            repetirMenu = true;
                            System.out.println("Error al cargar la partida");
                        }
                        else
                            repetirMenu = false;
                        guardado = false;
                        break;
                    }
                    case 3:
                    {
                        problema.cargar(obtenerRuta(), error);
                        salida.set(false);
                        jugar.set(false);
                        if(error.get())
                        {
                            repetirMenu = true;
                            System.out.println("Error al cargar la partida");
                        }
                        else
                            repetirMenu = false;
                        guardado = false;
                        break;
                    }
                    case 4:
                    {
                        problema.guardar(problema.getFichero());
                        salida.set(false);
                        jugar.set(false);
                        repetirMenu = true;
                        guardado = true;
                        break;
                    }
                    case 5:
                    {
                        LecturaTeclado fichero = new LecturaTeclado();
                        System.out.println("Introduzca la ruta y nombre del fichero donde se va a guardar la partida");
                        problema.guardar(fichero.leerLinea());
                        salida.set(false);
                        jugar.set(false);
                        repetirMenu = true;
                        guardado = true;
                        break;
                    }
                    case 6:
                    {
                        repetirMenu = false;
                        if(guardado)
                        {
                            System.out.println("�Adi�s!");
                            salida.set(true);
                        }
                        else
                        {
                            LecturaTeclado fichero = new LecturaTeclado();
                            String respuesta;
                            do
                            {
                                System.out.println("�Est� seguro que desea salir sin guardar la partida? (si/no)");
                                respuesta = fichero.leerLinea();
                                if(respuesta.equals("si"))
                                {
                                    System.out.println("�Adi�s!");
                                    salida.set(true);
                                }
                                else if(respuesta.equals("no"))
                                {
                                    salida.set(false);
                                    repetirMenu = true;
                                }
                                else
                                    System.out.println("Respuesta incorrecta");
                            }
                            while(!respuesta.equals("si") && !respuesta.equals("no"));
                        }
                        jugar.set(false);
                        break;
                    }
                    default:
                    {
                        System.out.println("Elecci�n incorrecta");
                        repetirMenu = true;
                        guardado = false;
                    }
                }
            }
            else if(tipoMenu == -1)
            {
                switch(eleccion)
                {
                    case 1:
                    {
                        problema.cargar(problema.getFichero(), error);
                        salida.set(false);
                        jugar.set(false);
                        if(error.get())
                        {
                            repetirMenu = true;
                            System.out.println("Error al cargar la partida");
                        }
                        else
                            repetirMenu = false;
                        break;
                    }
                    case 2:
                    {
                        problema.cargar(obtenerRuta(), error);
                        salida.set(false);
                        jugar.set(false);
                        if(error.get())
                        {
                            repetirMenu = true;
                            System.out.println("Error al cargar la partida");
                        }
                        else
                            repetirMenu = false;
                        break;
                    }
                    case 3:
                    {
                        System.out.println("�Adi�s!");
                        salida.set(true);
                        jugar.set(false);
                        repetirMenu = false;
                        break;
                    }
                    default:
                    {
                        System.out.println("Elecci�n incorrecta");
                        repetirMenu = true;
                    }
                }
            }
            else
            {
                System.out.println("Elecci�n incorrecta");
                repetirMenu = true;
            }
        }
        while(repetirMenu);
    }
}