import java.io.*;

/**
 * Clase que sirve de envoltura a la salida de datos a un fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */
public class EscrituraFichero
{
    private String _nombreFichero;
    private PrintWriter _escribir;
    
    /**
     * Crea una nueve instancia de EscrituraFichero
     * @param nombreFichero Nombre del fichero que va a ser escrito 
     */
    public EscrituraFichero(String nombreFichero)
    {
        _nombreFichero = nombreFichero;
        
        try
        {
            _escribir = new PrintWriter(new BufferedWriter(new FileWriter(_nombreFichero, false)));
        }
        catch(IOException e) 
        {
            System.out.println(e.toString());
        }   
    }

    /**
     * Escribe una cadena sin retorno de carro
     * @param c Cadena a escribir 
     */
    public void print(String c)
    {
        _escribir.print(c);
    }
    
    /**
     * Escribe una cadena con retorno de carro
     * @param c Cadena a escribir
     */ 
    public void println(String c)
    {
        _escribir.println(c);
    }
    
     /**
     * Escribe un entero con retorno de carro
     * @param n Cadena a escribir
     */ 
    public void println(int n)
    {
        _escribir.println(n);
    }
    
    /**
     * Escribe un "intro" en el fichero
     */ 
    public void println()
    {
        _escribir.println();
    }
    
    /**
     * Cierra el fichero
     */
    public void cerrar()
    {
        _escribir.close();
    }
}