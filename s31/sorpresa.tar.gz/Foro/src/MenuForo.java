
/**
 * En la clase MenuForo se muestra el men�, se crean los objetos y se llama a los m�todos seg�n la opci�n elegida
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class MenuForo
{
    Foro _foro;

    /**
     * Se crea un MenuForo
     */
    
    public MenuForo(Foro foro)
    {
        _foro = foro;
    }

    /**
     * Se controla el men�: se lee la opci�n elegida y se crean los objetos y se llama a los m�todos que corresponda seg�n esta opci�n
     * @return True si se elige Salir
     */
    
    public boolean iniciar()
    {
        int lee;
        boolean salir = false;
        do
        {
            lee = menuPrincipal();
            switch(lee) // Controlamos el men�.
            {
                case 1 : 
                {
                    MostrarConversaciones Muestra = new MostrarConversaciones(_foro);
                    Muestra.mostrarConversaciones( Muestra.ordenarConversaciones(_foro.obtenerTodasConversaciones()) );
                    salir = false;
                }
                break;
                case 2 : 
                {
                    Buscar busqueda = new Buscar();
                    busqueda.mostrarBusqueda(busqueda.buscarMensajes(busqueda.ordenarMensajes(busqueda.obtenerMensajes(_foro.obtenerTodasConversaciones(), _foro)), busqueda.obtenerFecha(), busqueda.obtenerTexto()));
                    salir = false;
                }
                break;
                case 3 : 
                {
                    Usuario usuario = new Usuario(_foro);
                    salir = false;
                }
                break;
                case 4 : 
                {
                    Conversacion conversacion = new Conversacion(_foro);
                    salir = false;
                }
                break;
                case 5 :
                {
                    Mensaje mensaje = new Mensaje(_foro);
                    salir = false;
                }
                break;
                case 6 : // Se pasa al men� de opciones
                {
                    do
                    {
                        lee = menuOpciones();
                        switch(lee)
                        {
                            case 1 :
                            {
                                // Se valida el usuario para poder realizar la opci�n
                                int x = 0;
                                String codigo, contrasegna;
                                Datos datos = new Datos();
                                Teclado teclas = new Teclado();
                                System.out.println("Introduzca su codigo de usuario: ");
                                codigo = teclas.leerLinea();
                                System.out.println("Introduzca su contrase�a:");
                                contrasegna = teclas.leerLinea();
                                if(datos.comprobarUsuario(_foro, codigo, contrasegna) == true)
                                {
                                    x = datos.posicionUsuario(_foro, codigo);
                                    _foro.obtenerUsuario(x).modificarContrasegna();
                                }
                                else
                                {
                                    System.out.println("No esta autorizado para realizar esta opcion");
                                }
                                salir = false;
                            }
                            break;
                            case 2 :
                            {
                                // Se valida el usuario para poder realizar la opci�n
                                int x = 0;
                                String codigo, contrasegna;
                                Datos datos = new Datos();
                                Teclado teclas = new Teclado();
                                System.out.println("Introduzca su codigo de usuario: ");
                                codigo = teclas.leerLinea();
                                System.out.println("Introduzca su contrase�a:");
                                contrasegna = teclas.leerLinea();
                                if(datos.comprobarUsuario(_foro, codigo, contrasegna) == true)
                                {
                                    x = datos.posicionUsuario(_foro, codigo);
                                    _foro.obtenerUsuario(x).modificarApodo();
                                }
                                else
                                {
                                    System.out.println("No esta autorizado para realizar esta opcion");
                                }
                                salir = false;
                            }
                            break;
                            case 3 :
                            {
                                salir = true;
                            }
                            break;
                            default: {System.out.println("Opcion incorrecta"); salir = false;}
                        }
                    }while(salir == false);
                    salir = false;
                }
                break;
                case 7 :
                {
                    System.out.println("Gracias por utilizar el foro");
                    _foro.guardar();
                    salir = true;
                }
                break;
                default: {System.out.println("Opcion incorrecta"); salir = false;}
            }
        }while(salir == false);
        return salir;
    }
    
    /**
     * Se muestra el men� principal
     * @return La opci�n elegida
     */
    
    public int menuPrincipal()
    {
        int opcion;
        Teclado tc;
        tc = new Teclado();
        opcion = 0;
        System.out.println(); // Mostramos el men�
        System.out.println("--------------------------------------------------");
        System.out.println("                       FORO                       ");
        System.out.println("--------------------------------------------------");
        System.out.println("1. - Consultar conversaciones");
        System.out.println("2. - Buscador");
        System.out.println("3. - Alta de usuario");
        System.out.println("4. - Alta de conversacion");
        System.out.println("5. - Alta de mensaje");
        System.out.println("6. - Opciones");
        System.out.println("7. - Salir");
        System.out.println();
        System.out.println();
        System.out.println("Seleccione una opcion...");
        opcion = tc.leerEntero();
        return opcion;
    }
    
    /**
     * Se muestra el menuOpciones
     * @return La opci�n elegida
     */
    
    public int menuOpciones()
    {
        int opcion;
        Teclado tc;
        tc = new Teclado();
        opcion = 0;
        System.out.println(); // Mostramos el men�
        System.out.println("--------------------------------------------------");
        System.out.println("                     OPCIONES                     ");
        System.out.println("--------------------------------------------------");
        System.out.println("1. - Modificar contrase�a de usuario");
        System.out.println("2. - Modificar apodo de usuario");
        System.out.println("3. - Volver");
        System.out.println();
        System.out.println();
        System.out.println("Seleccione una opcion...");
        opcion = tc.leerEntero();
        return opcion;
    }
}