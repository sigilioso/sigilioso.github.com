
/**
 * La clase PruebaForo es la clase principal de la aplicaci�n
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class PruebaForo
{

    /**
     * El m�todo main es el que controla la iniciaci�n del programa
     * @param args El nombre del fichero de propiedades
     */

    public static void main(String[] args)
    {
        boolean salir = false, falloFichero = false;
        if(args.length != 0) // Se comprueba si hay argumento de entrada
        {
            FicheroLectura fichero = new FicheroLectura(args[0]);
            if(fichero.obtenerFallo() == true) // Si no encuentra el fichero con el nombre recibido por el argumento de entrada se toma por defecto "config.propiedades"
            {
                args[0] = "config.propiedades";
            }
            Foro foro;
            foro = new Foro(args[0]);
            foro.inicializarUsuarios();
            foro.inicializarConversaciones();
            MenuForo menuForo;
            menuForo = new MenuForo(foro);
            do // Se inicia el men�
            {
                salir = menuForo.iniciar();
            }while(salir != true);
        }
        else // Si no hay argumento de entrada se le pasa por defecto "config.propiedades" como nombre de fichero
        {
            Foro foro = new Foro("config.propiedades");
            foro.inicializarUsuarios();
            foro.inicializarConversaciones();
            MenuForo menuForo = new MenuForo(foro);
            do // Se inicia el men�
            {
                salir = menuForo.iniciar();
            }while(salir != true);
        }
    }
}