
/**
 * La clase Mensaje permite la creaci�n de mensajes desde el men� y desde el fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Mensaje
{
    char _identificador;
    String _titulo;
    Fecha _fechaAlta;
    String _codigoUsuario;
    String _texto;
    
    /**
     * Se crea un nuevo Mensaje desde el men�
     * @param foro El foro que contiene las conversaciones que a su vez contienen los mensajes
     */
    
    public Mensaje(Foro foro) 
    {
        int x = 0;
        _identificador = 'M';
        String codigo, contrasegna;
        String tema;
        boolean exito = false;
        Datos datos = new Datos();
        Teclado teclas = new Teclado();
        System.out.println("-------------------- ALTA DE MENSAJE --------------------");
        System.out.println("Introduzca su codigo de usuario: ");
        codigo = teclas.leerLinea();
        System.out.println("Introduzca su contrase�a:");
        contrasegna = teclas.leerLinea();
        _codigoUsuario = codigo;
        exito = datos.comprobarUsuario(foro, codigo, contrasegna); // Se comprueba la existencia del usuario y se valida con su contrase�a
        if(exito != false)
        {
            System.out.println("Introduzca el tema de la conversacion:");
            tema = teclas.leerLinea();
            if(datos.comprobarExisteConversacion(foro, tema) == true) // Se comprueba que existe la conversaci�n con el tema introducido
            {
                x = datos.posicionConversacion(foro, tema); // Se guarda la posici�n de la conversaci�n
                if(foro.comprobarEspacioMatriz("mensaje", x) == false) // Se comprueba el espacio del vector de mensajes
                {
                    System.out.println("MENSAJE");
                    System.out.println("Introduzca el titulo del mensaje");
                    _titulo = teclas.leerLinea().trim();
                    System.out.println("Introduzca la fecha de alta del mensaje:");
                    _fechaAlta = new Fecha();
                    System.out.println("Introduzca el cuerpo del mensaje:");
                    _texto = teclas.leerLinea().trim();
                    if(_fechaAlta.obtenerCadenaFecha() != null) // Se comprueba la existencia de la fecha
                    {
                        if((_titulo.length() < 1) || (_texto.length() < 1) || (_fechaAlta.comprobarFechaValida() == true) || ((_fechaAlta.esPosterior(foro.obtenerConversacion(x).obtenerFechaInicio()) == false) && (_fechaAlta.esIgual(foro.obtenerConversacion(x).obtenerFechaInicio()) == false)))
                        {
                            // Se comprueba que el titulo, texto y fecha son valores correctos. La fecha del mensaje debe ser posterior a la fecha de la conversaci�n
                            System.out.println("Error en los datos introducidos, mensaje no a�adido");
                        }
                        else
                        {
                            foro.obtenerConversacion(x).agnadirMensaje(this); // Se a�ade el mensaje al vector de la conversaci�n correspondiente
                            System.out.println("Mensaje a�adido");
                        }
                    }
                    else
                    {
                        System.out.println("Error en el formato de la fecha, deben ser valores numericos enteros y del formato dd/mm/aaaa, mensaje no a�adido");
                    }
                }
                else
                {
                    System.out.println("Se ha superado el numero maximo de mensajes");
                    System.out.println("Mensaje no a�adido");
                }
            }
            else
            {
                System.out.println();
                System.out.println("No existe la conversacion");
                System.out.println("Mensaje no a�adido");
            }
        }
    }
    
    /**
     * Se crea un Mensaje desde el fichero
     * @param identificador Identificador del mensaje
     * @param titulo Titulo del mensaje
     * @param fechaAlta Fecha del mensaje
     * @param codigoUsuario Codigo del usuario del mensaje
     * @param texto Texto del mensaje
     */
    
    public Mensaje(char identificador, String titulo, Fecha fechaAlta, String codigoUsuario, String texto)
    {
            _identificador = identificador;
            _titulo = titulo;
            _fechaAlta = fechaAlta;
            _codigoUsuario = codigoUsuario;
            _texto = texto;
     }
     
     /**
      * @return El identificador
      */
     
     public char obtenerIdentificador()
    {
        return _identificador;
    }
    
    /**
     * @return El titulo
     */
    
    public String obtenerTitulo()
    {
        return _titulo;
    }
    
    /**
     * @return La fecha
     */
    
    public Fecha obtenerFechaAlta()
    {
        return _fechaAlta;
    }
    
    /**
     * @return La cadena de la fecha
     */
    
    public String obtenerCadenaFechaAlta()
    {
        return _fechaAlta.obtenerCadenaFecha();
    }
    
    /**
     * @return El codigo del usuario
     */
    
    public String obtenerCodigoUsuario()
    {
        return _codigoUsuario;
    }
    
    /**
     * @return El texto
     */
    
    public String obtenerTexto()
    {
        return _texto;
    }
}