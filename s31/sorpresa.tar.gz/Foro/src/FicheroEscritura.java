import java.io.*;

/**
 * Clase que sirve de envoltura a la salida de datos hacia un fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class FicheroEscritura
{
    String _nombreFichero;
    PrintWriter _escribe;
    
    /**
     * Se crea un nuevo FicheroEscritura
     * @param nombreFichero Nombre del fichero que va a ser escrito 
     */
    
    public FicheroEscritura(String nombreFichero)
    {
        _nombreFichero = nombreFichero;
        
        try
        {
            BufferedWriter escritura = new  BufferedWriter(new FileWriter(_nombreFichero, false)); 
            _escribe = new PrintWriter(escritura); //con true arriba a�adimos en vez de sobreescribir, no machacamos lo que ten�amos.
        }
        catch(java.io.IOException ex) {System.out.println("ERROR!!"+ ex);}   
    }

    /**
     * Escribe una cadena sin retorno de carro 
     */
    
    public void escribir(String cadena)
    {
        try
        {
            _escribe.print(cadena);
        }
        catch(Exception ex) {System.out.println("Error al escribir en el fichero" + ex);}
    }
    
    /**
     * Escribe una cadena con retorno de carro
     */ 
    
    public void escribirln(String cadena)
    {
        try
        {
            _escribe.println(cadena);
        }
        catch(Exception ex) {System.out.println("Error al escribir en el fichero" + ex);}
    }
    
    /**
     * Cierra el fichero
     */
    
    public void cerrarFichero()
    {
        try
        {
            _escribe.close();
        }
        catch(Exception ex) {System.out.println("Error al cerrar el fichero"+ ex); }
    }
}