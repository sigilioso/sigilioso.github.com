import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Clase que sirve de envoltura a la entrada est�ndar por teclado.
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Teclado
{
    BufferedReader _entrada;
    
    /**
     * Crea un nuevo Teclado
     */
    
    public Teclado() 
    {
        try
        {
            _entrada = new BufferedReader(new InputStreamReader(System.in));
        }
        catch(Exception e)
        {
            System.out.println("Error en la lectura de teclado");
        }
    }
    
    /**
     * Lee una linea de la entrada est�ndar
     * @return linea le�da
     */
    
    public String leerLinea()
    {
        String linea;
    
        linea = new String();
        try
        {
            linea = _entrada.readLine();
        }
        catch(Exception e)
        {
            System.out.println("Error en la lectura de teclado de una linea");
        }
        return linea;
    }
    
    /**
     * Lee una linea de la entrada, y convirtiendo la entrada en un entero
     * @return entero le�do
     */
    
    public int leerEntero()
    {
        int i = 0;
        try
        {
            i = Integer.parseInt(leerLinea());
        }
        catch(NumberFormatException e)
        {
            System.out.println("Error la cadena leida no es un entero");
        }
        return i;
    }
}