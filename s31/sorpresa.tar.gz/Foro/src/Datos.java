
/**
 * La clase Datos es una clase auxiliar que sirve para realizar algunas comprobaciones
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Datos
{
    
    /**
     * Se comprueba si el primer par�metro contiene al segundo
     * @param texto Es el texto donde se busca la cadena introducida por el usuario
     * @param cadena Es la cadena dada por el usuario para buscar en el texto
     * @return True si el texto contiene a la cadena
     */
    
    public boolean contiene(String texto, String cadena)
    {
        boolean ok = false;
        if (texto.indexOf(cadena) != -1)
        {
            ok = true;
        }
        return ok;     
    }
    
    /**
     * Se comrprueba la existencia del usuario en el foro
     * @param foro El propio foro
     * @param codigo El codigo del usuario a comprobar
     * @return True si existe el usuario
     */
    
    public boolean comprobarUsuario(Foro foro, String codigo)
    {
        int i = 0;
        boolean comprobacion=false;
        while((i < foro.obtenerNumUsuarios()) && (comprobacion == false))
        {
            if(foro.obtenerUsuario(i) != null)
            {
                if(codigo.equals((foro.obtenerUsuario(i)).obtenerCodigo()))
                {
                    comprobacion = true;
                }
                else
                {
                    comprobacion = false;
                }
            }
            i++;
        }
        return comprobacion;
    }
    
    /**
     * Se comprueba la existencia del usuario en el foro y se valida su contrase�a
     * @param foro El propio foro
     * @param codigo El c�digo del usuario
     * @param contrasegna La contrase�a del usuario
     * @return True si el usuario existe y su contrase�a es correcta
     */
    
    public boolean comprobarUsuario(Foro foro, String codigo, String contrasegna)
    {
        int i = 0, contador = 0;
        boolean existencia=false, comprobacion=false;
        String codigoUs, contrasegnaUs;
        while((i < foro.obtenerNumUsuarios()) && (existencia == false))
        {
            if(foro.obtenerUsuario(i) != null)
            {
                codigoUs = foro.obtenerUsuario(i).obtenerCodigo();
                if(codigo.compareTo(codigoUs) == 0 )
                {
                    contador = i;
                    existencia = true;
                }
            }
            i++;
        }
        if(existencia == true)
        {
            contrasegnaUs = foro.obtenerUsuario(contador).obtenerContrasegna();
            if(contrasegna.compareTo(contrasegnaUs) == 0 )
            {
                comprobacion = true;
                System.out.println("Usuario validado correctamente");
            }
            else
            {
                comprobacion = false;
                System.out.println("Contrase�a incorrecta");
            }
        }
        else
        {
            comprobacion = false;
            System.out.println("Error, el usuario no existe en el foro");
        }
        return comprobacion;
    }
    
    /**
     * Se comprueba que existe una conversaci�n en el foro con un tema determinado
     * @param foro El propio foro
     * @param tema El tema de la conversaci�n a comprobar
     * @return True si existe la conversaci�n
     */
    
    public boolean comprobarExisteConversacion(Foro foro, String tema)
    {
        int i = 0;
        boolean existencia = false;
        String tma;
        while((i < foro.obtenerNumConversaciones()) && (existencia == false))
        {
            if(foro.obtenerConversacion(i) != null)
            {
                tma = foro.obtenerConversacion(i).obtenerTema();
                if(tema.compareTo(tma) == 0)
                {
                    existencia = true;
                }
                else
                {
                    existencia = false;
                }
            }
            i++;
        }
        return existencia;
    }
    
    /**
     * @param foro El foro que contiene las conversaciones
     * @param tema El tema de la conversaci�n cuya posici�n se busca
     * @return La posici�n de la conversaci�n
     */
    
    public int posicionConversacion(Foro foro, String tema)
    {
        int i = 0;
        while((foro.obtenerConversacion(i).obtenerTema()).compareTo(tema) != 0)
        {
            i++;
        }
        return i;
    }

    /**
     * @param foro El foro que contiene los usuarios
     * @param codigo El c�digo del usuario cuya posici�n se busca
     * @return La posici�n del usuario
     */
    
    public int posicionUsuario(Foro foro, String codigo)
    {
        int i = 0;
        while((foro.obtenerUsuario(i).obtenerCodigo()).compareTo(codigo) != 0)
        {
            i++;
        }
        return i;
    }
    
    /**
     * Se recoge por teclado la fecha
     * @return Cadena de fecha
     */

    public String recogerFecha()
    {
        System.out.println("Introduzca la fecha: ");
        Teclado cadena = new Teclado();
        String fecha;
        fecha = cadena.leerLinea().trim();
        return fecha;
    }
    
    /**
     * Se comprueba que el formato de la fecha es correcto
     * @param f La cadena de fecha
     * @return True si la fecha tiene un formato correcto
     */
    
    public boolean comprobarFormatoFecha(String f)
    {
        boolean correcto = true;
        int inicio = 0, fin, dd, mm, aaaa;
        try
        {
            if(f.length() == 10)
            {
                fin = f.indexOf("/");
                if(fin == -1)
                {
                    correcto = false;
                    return correcto;
                }
                else
                {
                    if(fin == 2)
                    {
                        dd = Integer.parseInt(f.substring(inicio, fin));
                    }
                    else
                    {
                        correcto = false;
                        return correcto;
                    }
                    inicio = fin + 1;
                    fin = f.indexOf("/", inicio);
                    if(fin == 5)
                    {
                        mm = Integer.parseInt(f.substring(inicio, fin));
                    }
                    else
                    {
                        correcto = false;
                        return correcto;
                    }
                    inicio = fin + 1;
                    aaaa = Integer.parseInt(f.substring(inicio));
                }
            }
            else
            {
                correcto = false;
                return correcto;
            }
        }
        catch(NumberFormatException e)
        {
            correcto = false;
            return correcto;
        }
        correcto = true;
        return correcto;
    }
}