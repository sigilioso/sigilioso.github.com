import java.io.*;

/**
 * Clase que sirve de envoltura a la entrada de datos desde un fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class FicheroLectura
{
    String _nombreFichero;
    BufferedReader _lectura;
    boolean _fallo = false;
    
    /**
     * Crea un nuevo FicheroLectura
     * @param nombreFichero Nombre del fichero que va a ser le�do
     */
    
    public FicheroLectura(String nombreFichero)
    {
        _nombreFichero = nombreFichero;
        
       try
       {
           _lectura = new BufferedReader(new FileReader(_nombreFichero));
        }
        catch(java.io.FileNotFoundException fnfex)
        {
            System.out.println("Fichero no encontrado");
            _fallo = true;
        }
    }

    /**
     * Lee una linea
     * @return La linea le�da
     */
    
    public String leerLinea()
    {
        String lee = new String();
        try
        {
            lee = _lectura.readLine();
        }
        catch(Exception e) { System.out.println("Error en la lectura de la linea"); }
        return lee;
    }
    
    /**
     * Cierra el fichero 
     */
    
    public void cerrarFichero()
    {
        try
        {
            _lectura.close();
        }
        catch(Exception e) { System.out.println("Error al cerrar el fichero"); }
    }
    
    /**
     * @return True si ha habido fallo
     */
    
    public boolean obtenerFallo()
    {
        return _fallo;
    }
}
