/**
 * La clase Foro es la clase principal del programa. Lee el fichero de propiedades, inicializa el foro a partir de los ficheros de datos
 * y guarda los cambios en el foro al final de la ejecuci�n del programa.
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Foro
{
    Conversacion _conversacion[]; // Vector de conversaciones
    Usuario _usuario[]; // Vector de usuarios
    String _propiedadesNombreFicheros[]; // Vector que guarda el nombre de los ficheros de datos
    int _propiedadesNumerosMaximos[]; // Vector que guarda los n�meros m�ximos de conversaciones y usuarios extraidos de los ficheros de datos
    String _nombreFicheroPropiedades; // Nombre del fichero de configuraci�n
    
/**
 * Constructor de la clase Foro: inicializa los atributos a partir del fichero de configuraci�n
 * @param nombreFicheroPropiedades Nombre del fichero de propiedades
 */

    public Foro(String nombreFicheroPropiedades)
    {
        // Inicializaci�n de las propiedades con los valores predeterminados
        _propiedadesNombreFicheros = new String[2];
        _propiedadesNumerosMaximos = new int[2];
        _propiedadesNombreFicheros[0] = "usuarios.txt";
        _propiedadesNombreFicheros[1] = "conversaciones.txt";
        _propiedadesNumerosMaximos[0] = 10;
        _propiedadesNumerosMaximos[1] = 20;
        
        final String NOMBRE_FICHERO_USUARIOS = "nombre_fich_usuarios";
        final String NOMBRE_FICHERO_CONVERSACIONES = "nombre_fich_conversaciones";
        final String NUMERO_MAXIMO_USUARIOS = "num_max_usuarios";
        final String NUMERO_MAXIMO_CONVERSACIONES = "num_max_conversaciones";
        
        // Asignaci�n del nombre del fichero de propiedades recibido a partir del par�metro
        _nombreFicheroPropiedades = nombreFicheroPropiedades;
        // Inicio de lectura del fichero
        FicheroLectura fichero;
        fichero = new FicheroLectura(_nombreFicheroPropiedades);
        if(fichero.obtenerFallo() == false) // Fallo si no se encuentra el fichero
        {
            String s;
            int linea = 1;
            while((s = fichero.leerLinea()) != null)
            {
                s = s.trim();
                int inicio;
                try // Comprobaci�n de que las lineas son v�lidas
                {
                    if(s.length() >= 16) // Se controla que la cadena le�da posteriormente no se salga del �ndice, ya que la longitud de los nombres de las propiedades es >= 16
                    {                    // Si los nombres de las propiedades son correctos, se asigna el valor en el vector.
                        if((s.substring(0, NUMERO_MAXIMO_USUARIOS.length()).trim()).equals(NUMERO_MAXIMO_USUARIOS)) 
                        {
                            inicio = s.indexOf("=", NUMERO_MAXIMO_USUARIOS.length()) + 1;
                            if(inicio != 0)
                            {
                                _propiedadesNumerosMaximos[0] = Integer.parseInt(s.substring(inicio).trim());
                            }
                        }
                        else if((s.substring(0, NOMBRE_FICHERO_USUARIOS.length()).trim()).equals(NOMBRE_FICHERO_USUARIOS))
                        {
                            inicio = s.indexOf("=", NOMBRE_FICHERO_USUARIOS.length()) + 1;
                            if(inicio != 0)
                            {
                                _propiedadesNombreFicheros[0] = s.substring(inicio).trim();
                            }
                        }
                        else if((s.substring(0, NUMERO_MAXIMO_CONVERSACIONES.length()).trim()).equals(NUMERO_MAXIMO_CONVERSACIONES))
                        {
                            inicio = s.indexOf("=", NUMERO_MAXIMO_CONVERSACIONES.length()) + 1;
                            if(inicio != 0)
                            {
                                _propiedadesNumerosMaximos[1] = Integer.parseInt(s.substring(inicio).trim());
                            }
                        }
                        else if((s.substring(0, NOMBRE_FICHERO_CONVERSACIONES.length()).trim()).equals(NOMBRE_FICHERO_CONVERSACIONES))
                        {
                            inicio = s.indexOf("=", NOMBRE_FICHERO_CONVERSACIONES.length()) + 1;
                            if(inicio != 0)
                            {
                                _propiedadesNombreFicheros[1] = s.substring(inicio).trim();
                            }
                        }
                        else // Se muestra error si los nombres de las propiedades no son correctos
                        {
                            System.out.println("Error linea " + linea + " del fichero " + _nombreFicheroPropiedades);
                            System.out.println("<" + s + ">");
                        }
                    }
                    else // Se muestra error si la cadena le�da no tiene la logitud m�nima requerida
                    {
                        System.out.println("Error linea " + linea + " del fichero " + _nombreFicheroPropiedades);
                        System.out.println("<" + s + ">");
                    }
                }
                catch(NumberFormatException e) // Se captura el error si los valores de las propiedades num�ricas no son enteros
                {
                    System.out.println("Error linea " + linea + " del fichero " + _nombreFicheroPropiedades);
                    System.out.println("<" + s + ">");
                }
                linea = linea + 1; // Se aumenta el n�mero de linea
            }
            fichero.cerrarFichero(); // Se cierra el fichero
        }
        else // Si no se encuentra el fichero se cargan los valores por defecto
        {
            System.out.println("Cargados valores por defecto");
        }
        // Se inicializan los vectores de usuarios y conversaciones
        _usuario = new Usuario[_propiedadesNumerosMaximos[0]];
        _conversacion = new Conversacion[_propiedadesNumerosMaximos[1]];
    }
    
    /**
     * @param indice Posici�n de la conversaci�n que se quiere obtener 
     * @return conversaci�n en la posici�n del par�metro recibido
     */
    
    public Conversacion obtenerConversacion(int indice)
    {
        return _conversacion[indice];
    }
    
    /**
     * @return vector con todas las conversaciones
     */
    
    public Conversacion[] obtenerTodasConversaciones()
    {
        return _conversacion;
    }
    
    /**
     * @param indice Posici�n del usuario que se quiere obtener 
     * @return usuario en la posici�n del par�metro recibido
     */
    
    public Usuario obtenerUsuario(int indice)
    {
        return _usuario[indice];
    }
    
    /**
     * @return vector con todos los usuarios
     */
    
    public Usuario[] obtenerTodosUsuarios()
    {
        return _usuario;
    }
    
    /**
     * @return n�mero de usuarios que han sido a�adidos en el vector de usuarios
     */
    
    public int obtenerNumUsuarios()
    {
        int i = 0, contador = 0;
        if(_usuario[obtenerNumMaxUsuarios() - 1] == null) // Se incrementa el contador si la matriz no est� llena
        {
            while(_usuario[i] != null)
            {
                contador = contador + 1;
                i = i + 1;
            }
        }
        else // Se da el n�mero m�ximo si la matriz est� llena
        {
            contador = obtenerNumMaxUsuarios();
        }
        return contador;
    }
    
    /**
     * @return n�mero de conversaciones que han sido a�adidas en el vector de conversaciones
     */
    
    public int obtenerNumConversaciones()
    {
        int i = 0, contador = 0;
        if(_conversacion[obtenerNumMaxConversaciones() - 1] == null) // Se incrementa el contador si la matriz no est� llena
        {
            while(_conversacion[i] != null)
            {
                contador = contador + 1;
                i = i + 1;
            }
        }
        else // Se da el n�mero m�ximo si la matriz est� llena
        {
            contador = obtenerNumMaxConversaciones();
        }
        return contador;
    }
    
    /**
     * @return n�mero m�ximo de usuarios
     */
    
    public int obtenerNumMaxUsuarios()
    {
        int numero;
        numero = _propiedadesNumerosMaximos[0];
        return numero;
    }
    
    /**
     * @return n�mero m�ximo de conversaciones
     */
    
    public int obtenerNumMaxConversaciones()
    {
        int numero;
        numero = _propiedadesNumerosMaximos[1];
        return numero;
    }
    
    /**
     * @return nombre del fichero de usuarios
     */
    
    public String obtenerNombreFicheroUsuarios()
    {
        return _propiedadesNombreFicheros[0];
    }
    
    /**
     * @return nombre del fichero de conversaciones
     */
    
    public String obtenerNombreFicheroConversaciones()
    {
        return _propiedadesNombreFicheros[1];
    }
    
    /**
     * El m�todo agnadirConversacion coloca la conversaci�n recibida como par�metro en la �ltima posici�n libre del vector de conversaciones 
     * @param conversacion Conversaci�n le�da del fichero del fichero o creada utilizando el men�
     */
    
    public void agnadirConversacion(Conversacion conversacion)
    {
        int i = 0;
        if(_conversacion[obtenerNumMaxConversaciones() - 1] == null)
        {
            while(_conversacion[i] != null)
            {
                i++;
            }
            _conversacion[i] = conversacion;
        }
    }
    
    /**
     * El m�todo agnadirUsuario coloca el usuario recibido como par�metro en la �ltima posici�n libre del vector de usuarios 
     * @param usuario Usuario le�do del fichero del fichero o creado utilizando el men�
     */
    
    public void agnadirUsuario(Usuario usuario)
    {
        int i = 0;
        if(_usuario[obtenerNumMaxUsuarios() - 1] == null)
        {
            while(_usuario[i] != null)
            {
                i++;
            }
            _usuario[i] = usuario;
        }
    }
    
    /**
     * El m�todo comprobarEspacioMatriz comprueba si hay espacio en los vectores de usuario, conversacion y mensaje
     * @param nombre Cadena que identifica el tipo de vector que se va a comprobar
     * @param indice Posici�n de la conversaci�n en la que est� el vector de mensajes a comprobar
     * @return true si el vector est� lleno
     */
    
    public boolean comprobarEspacioMatriz(String nombre, int indice)
    {
        boolean llena = false;
        if(indice == -1) // Si el �nidice es -1 significa que el vector no es de mensajes
        {
            if(nombre == "usuario")
            {
                if(obtenerNumUsuarios() == obtenerNumMaxUsuarios())
                {
                    llena = true;
                }
                else
                {
                    llena = false;
                }
            }
            if(nombre == "conversacion")
            {
                if(obtenerNumConversaciones() == obtenerNumMaxConversaciones())
                {
                    llena = true;
                }
                else
                {
                    llena = false;
                }
            }
        }
        else // Si el �ndice es distinto de -1 se comprueba un vector de mensajes
        {
            if(nombre == "mensaje")
            {
                if(obtenerConversacion(indice).obtenerNumMensajes() == 50)
                {
                    llena = true;
                }
                else
                {
                    llena = false;
                }
            }
        }
        return llena;
    }
    
    /**
     * El m�todo guardar salva los datos en los ficheros
     */
    
    public void guardar()
    {   // Se abren los ficheros con los nombres correspondientes
        FicheroEscritura ficheroUsuarios;
        FicheroEscritura ficheroConversaciones;
        ficheroUsuarios = new FicheroEscritura(obtenerNombreFicheroUsuarios());
        ficheroConversaciones = new FicheroEscritura(obtenerNombreFicheroConversaciones());
        int i=0, j=0, k=0;
        for(i = 0; i < _usuario.length; i++) // Se guardan los usuarios en el fichero
        {
            if(_usuario[i] != null)
            {
                String tempUs;
                tempUs = ( _usuario[i].obtenerCodigo() + " & " + _usuario[i].obtenerContrasegna() + " & " + _usuario[i].obtenerApodo() );
                ficheroUsuarios.escribirln(tempUs);
            }
        }
        for(j = 0; j < _conversacion.length; j++) // Se guardan las conversaciones en el fichero
        {
            if(_conversacion[j] != null)
            {
                String tempConv;
                tempConv = (_conversacion[j].obtenerIdentificador() + " & "+ _conversacion[j].obtenerTema() + " & " + _conversacion[j].obtenerCadenaFechaInicio());
                ficheroConversaciones.escribirln(tempConv);
                for(k = 0; k < _conversacion[j].obtenerTodosMensajes().length; k++) // Se guardan los mensajes de cada conversaci�n en el fichero
                {
                    while(_conversacion[j].obtenerMensaje(k) != null)
                    {
                        String tempMens;
                        tempMens = (_conversacion[j].obtenerMensaje(k).obtenerIdentificador() + " & " + _conversacion[j].obtenerMensaje(k).obtenerTitulo() + " & " +
                                    _conversacion[j].obtenerMensaje(k).obtenerCodigoUsuario() + " & " + _conversacion[j].obtenerMensaje(k).obtenerCadenaFechaAlta() +
                                    " & " + _conversacion[j].obtenerMensaje(k).obtenerTexto() );
                                    ficheroConversaciones.escribirln(tempMens);
                        k++;
                    }
                }
                ficheroConversaciones.escribirln(_conversacion[j].obtenerFin());
            }
        }
        ficheroUsuarios.cerrarFichero();
        ficheroConversaciones.cerrarFichero();
        System.out.println("Cambios guardados"); // Se cierran los ficheros al terminar de salvar los datos
    }
    
    /**
     * El m�todo inicializarUsuarios lee el fichero de usuarios y carga los datos a la estructura del programa
     */
    
    public void inicializarUsuarios()
    {
        char separador = '&'; 
        FicheroLectura fichero;
        fichero = new FicheroLectura(obtenerNombreFicheroUsuarios()); // Se abre el fichero de usuarios
        String linea;
        int numLinea = 1, contador = 0;
        if(fichero.obtenerFallo() == false) // Fallo si no se encuentra el fichero
        {
            while((linea = fichero.leerLinea()) != null) // Se leen las lineas
            {
                linea = linea.trim(); 
                int x, y;
                x = linea.indexOf(separador);
                y = linea.indexOf(separador, x+1); // Se guarda la posici�n de los separadores
                if((x != -1) && (y != -1)) // Se comprueba que hay dos separadores en la linea
                {
                    String codigo;
                    String contrasegna;
                    String apodo;
                    codigo = linea.substring(0, x); 
                    contrasegna = linea.substring(x+1, y);
                    apodo = linea.substring(y+1);
                    codigo = codigo.trim();
                    contrasegna = contrasegna.trim();
                    apodo = apodo.trim();
                    if( (codigo.length() >= 1) && (contrasegna.length() >= 1) && (apodo.length() >= 1) ) // Se comprueba que no falta ning�n dato
                    {
                        Datos datos = new Datos();
                        if(datos.comprobarUsuario(this, codigo) == false) // Se comprueba la no existencia del usuario
                        {
                            if(comprobarEspacioMatriz("usuario", -1) == false) // Se comprueba que hay espacio en el vector
                            {
                                Usuario user = new Usuario(codigo, contrasegna, apodo, this); // Se crea el usuario
                                agnadirUsuario(user);  // Se a�ade el nuevo usuario al vector
                            }
                            else
                            {
                                System.out.println("Error linea " + numLinea + " del fichero " + obtenerNombreFicheroUsuarios());
                                System.out.println("<" + linea + ">");
                            }
                            contador = contador + 1; // Cuenta los usuarios con formato correcto
                        }
                        else
                        {
                            System.out.println("Error linea " + numLinea + " del fichero " + obtenerNombreFicheroUsuarios());
                            System.out.println("<" + linea + ">");   
                        }
                    }
                    else
                    {
                        System.out.println("Error linea " + numLinea + " del fichero " + obtenerNombreFicheroUsuarios());
                        System.out.println("<" + linea + ">");
                    }
                }
                else if(linea.length() != 0)
                {
                    System.out.println("Error linea " + numLinea + " del fichero " + obtenerNombreFicheroUsuarios());
                    System.out.println("<" + linea + ">");
                }
                numLinea ++; 
            }
            if(contador > obtenerNumMaxUsuarios()) 
            {   // Se muestra el n�mero de usuarios que no han sido a�adidos por falta de espacio en el vector
                System.out.println("Se ha superado el numero maximo de usuarios");
                System.out.println((contador - obtenerNumMaxUsuarios()) + " usuarios no a�adidos");
                System.out.println("Los usuarios no a�adidos quedaran invalidados y borrados del fichero de datos");
            }
            fichero.cerrarFichero(); // Se cierra el fichero
        }
    }
    
    /**
     * El m�todo inicializarConversaciones lee el fichero de conversaciones y carga los datos a la estructura del programa
     */
     
    public void inicializarConversaciones()
    {
        char separador = '&';
        FicheroLectura fichero;
        int matrizErrores[]; // Se define un vector para guardar el n�mero de cada linea err�nea
        fichero = new FicheroLectura(_propiedadesNombreFicheros[1]); // Se abre el fichero de conversaciones
        int numLinea = 1, contadorLineas = 1; // Estas variables se inicializan a uno porque cuentan las lineas. Se comienza a leer en la linea uno
        int tempNumLinea1 = 0, contadorConversaciones = 0, contadorMensajes = 0, contadorMensajesTotales = 0;  
        int i = -1; // El �ndice utilizado para la matrizErrores comienza en -1 ya que se incrementa una vez antes de manejar el vector
        String linea;
        Conversacion conversacion;
        Mensaje mensaje;
        if(fichero.obtenerFallo() == false) // Fallo si no se encuentra el fichero
        {
            FicheroLectura ficheroError;
            ficheroError = new FicheroLectura(_propiedadesNombreFicheros[1]); // Se vuelve a abrir el fichero para contar las lineas
            while((linea = ficheroError.leerLinea()) != null)
            {
                contadorLineas++;
            }
            matrizErrores = new int[contadorLineas]; // Se crea el vector de lineas err�neas de tama�o n�mero de lineas
            ficheroError.cerrarFichero(); // Se cierra el fichero que se abri� para contar las lineas
            while((linea = fichero.leerLinea()) != null) // Se leen las lineas del fichero
            {
                linea = linea.trim();
                if((linea.length() != 0) && (linea.charAt(0) != 'C') && (linea.charAt(0) != 'c')) //Se comprueba que que la l�nea sea una conversaci�n o un intro
                {
                    // Se a�ade al vector de errores el n�mero de la linea fallida
                    i++;
                    matrizErrores[i] = numLinea;
                    numLinea++;
                }
                else if(linea.length() == 0) // Si es un intro se �nicamente se incrementa el n�mero de linea
                {
                    numLinea++;
                }
                else // Al no ser un intro, es una conversaci�n
                {
                    int x, y;
                    x = linea.indexOf(separador);
                    y = linea.indexOf(separador, x+1); // Se guarda la posici�n de los separadores
                    if((x != -1) && (y != -1)) // Se comprueba que hay dos dos separadores en la linea
                    {
                        char identificadorC = 'C'; //como ya se ha comprobado que es 'C' o 'c', se le pasa directamente 'C'
                        String tema;
                        String cadenaFechaInicio;
                        tema = linea.substring(x+1, y).trim();
                        cadenaFechaInicio = linea.substring(y+1).trim();
                        if((tema.length() < 1) || (cadenaFechaInicio.length() < 1) ) // Se comprueba que no falte ning�n dato
                        {
                            // Se a�ade al vector de errores el n�mero de la linea fallida
                            i++;
                            matrizErrores[i] = numLinea;
                            numLinea++;
                        }
                        else
                        {
                            Datos datos = new Datos();
                            if(datos.comprobarExisteConversacion(this, tema) == true) // Se comprueba que no existe una conversaci�n con ese tema
                            {
                                // Se a�ade al vector de errores el n�mero de la linea fallida
                                i++;
                                matrizErrores[i] = numLinea;
                                numLinea++;
                            }
                            else
                            { 
                                if(datos.comprobarFormatoFecha(cadenaFechaInicio) == false) // Se comprueba que el formato de la fecha es correcto
                                {
                                    // Se a�ade al vector de errores el n�mero de la linea fallida
                                    i++;
                                    matrizErrores[i] = numLinea;
                                    numLinea++;
                                }
                                else
                                {
                                    Fecha fechaInicio = new Fecha(cadenaFechaInicio);
                                    if(fechaInicio.comprobarFechaValida() == true) // Se comprueba que la fecha existe en nuestro calendario
                                    {
                                        // Se a�ade al vector de errores el n�mero de la linea fallida
                                        i++;
                                        matrizErrores[i] = numLinea;
                                        numLinea++;
                                    }
                                    else
                                    {
                                        Mensaje mensajes[] = new Mensaje[50];
                                        conversacion = new Conversacion(mensajes, tema, fechaInicio, identificadorC, this); // Se crea la conversaci�n
                                        tempNumLinea1 = numLinea; // Se guarda el valor de la linea de la conversaci�n
                                        numLinea++; 
                                        boolean finWhile = false;
                                        while(finWhile == false) // Se comienza la lectura de los mensajes
                                        {
                                            linea = fichero.leerLinea();
                                            if(linea != null) // Se comprueba que la linea no es nula
                                            {
                                                linea = linea.trim();
                                                if((linea.compareTo("-FIN-")) != 0) // Se comprueba que la linea no es la de fin
                                                {
                                                    finWhile = false;
                                                    if((linea.length()) == 0) // Si la linea es un intro �nicamente se incrementa el n�mero de linea
                                                    {
                                                        numLinea++;
                                                    }
                                                    else
                                                    {
                                                        if((linea.charAt(0) != 'M') && (linea.charAt(0) != 'm')) // Se comprueba si la linea es un mensaje
                                                        {
                                                            if((linea.charAt(0) == 'C') || (linea.charAt(0) == 'c')) // Se comprueba si la linea es una conversacion
                                                            {
                                                                int tempNumLinea2 = numLinea; // Se guarda el n�mero de la �ltima linea le�da
                                                                String temp;
                                                                FicheroLectura ficheroTemp = new FicheroLectura(_propiedadesNombreFicheros[1]); // Se vuelve a abrir el fichero temporalmente
                                                                for(int k = 0; k < tempNumLinea2; k++) // Se alcanza en el fichero abierto temporalmente la �ltima posici�n le�da en el primer fichero
                                                                {
                                                                    temp = ficheroTemp.leerLinea();
                                                                }
                                                                numLinea++;
                                                                boolean finPasada = false;
                                                                int ultimaLineaEscrita = numLinea; 
                                                                while(finPasada == false) // Se comienza la b�squeda de la linea nula o fin
                                                                {
                                                                    linea = ficheroTemp.leerLinea();
                                                                    if(linea != null) // Se comprueba que la linea no es nula
                                                                    {
                                                                        linea = linea.trim();
                                                                        if((linea.compareTo("-FIN-")) != 0) // Se comprueba que la linea no es la de fin
                                                                        {
                                                                            if(linea.length() != 0) // Si la linea est� escrita, ultimaLineaEscrita se incrementa
                                                                            {
                                                                                ultimaLineaEscrita++;
                                                                            }
                                                                            numLinea++;
                                                                            finPasada = false;
                                                                        }
                                                                        else // Si la linea es la de fin se da salida al while
                                                                        {
                                                                            finPasada = true;
                                                                        }
                                                                    }
                                                                    else // Si la linea es nula se da salida al while
                                                                    {
                                                                        finPasada = true;
                                                                    }
                                                                }
                                                                ficheroTemp.cerrarFichero(); // Se cierra el fichero temporal
                                                                finWhile = true; 
                                                                
                                                                if(linea != null) 
                                                                {
                                                                    // Si la linea no es nula, se ha encontrado una linea de fin, por lo que se desecha la conversaci�n le�da en segundo lugar
                                                                    System.out.println("Error desde linea " + tempNumLinea2 + " a " + (ultimaLineaEscrita - 1) + " del fichero " + obtenerNombreFicheroConversaciones());
                                                                    System.out.println("Se ha desechado la conversacion que no finaliza");
                                                                    int aux = tempNumLinea2;
                                                                    for(int j = 0; j < (numLinea - tempNumLinea2); j++) // Se recorren las lineas err�neas desde el principio de la conversaci�n le�da en segundo lugar
                                                                    {
                                                                        // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                        i++;
                                                                        matrizErrores[i] = aux;
                                                                        aux++;
                                                                        linea = fichero.leerLinea().trim();
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    // Si la linea es nula se desecha la conversaci�n completa, por no haberse encontrado una linea de fin
                                                                    System.out.println("Error desde linea " + tempNumLinea1 + " hasta el final del fichero " + obtenerNombreFicheroConversaciones());
                                                                    System.out.println("Se ha desechado la conversacion que no finaliza");
                                                                    int aux = tempNumLinea1;
                                                                    for(int j = 0; j < (numLinea - tempNumLinea1); j++) // Se recorren las lineas err�neas desde el principio de la conversaci�n
                                                                    {
                                                                        // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                        i++;
                                                                        matrizErrores[i] = aux;
                                                                        aux++;
                                                                        linea = fichero.leerLinea();
                                                                    }
                                                                }
                                                            }
                                                            else
                                                            {
                                                                // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                i++;
                                                                matrizErrores[i] = numLinea;
                                                                numLinea++;
                                                            }
                                                        }
                                                        else // Se lee una linea de mensaje
                                                        {
                                                            int a, b, c ,d;
                                                            a = linea.indexOf(separador);
                                                            b = linea.indexOf(separador, a+1);
                                                            c = linea.indexOf(separador, b+1);
                                                            d = linea.indexOf(separador, c+1); // Se guarda la posici�n de los separadores
                                                            if( (a != -1) && (b != -1) && (c != -1) && (d != -1) ) // Se comprueba que la linea tiene cuatro separadores
                                                            {
                                                                char identificadorM = 'M'; // Como ya se ha comprobado que es 'm' o 'M' se le pasa 'M' directamente
                                                                String titulo;
                                                                String codigoUsuario;
                                                                String cadenaFechaAlta;
                                                                String texto;
                                                                titulo = linea.substring(a+1, b).trim();
                                                                codigoUsuario = linea.substring(b+1, c).trim();
                                                                cadenaFechaAlta = linea.substring(c+1, d).trim();
                                                                texto = linea.substring(d+1).trim();
                                                                if( (titulo.length() < 1) || (codigoUsuario.length() < 1) || (cadenaFechaAlta.length() < 1) || (texto.length() < 1) ) // Se comprueba si falta alg�n dato
                                                                {
                                                                    // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                    i++;
                                                                    matrizErrores[i] = numLinea;
                                                                    numLinea++;
                                                                }
                                                                else
                                                                {
                                                                    if(datos.comprobarUsuario(this, codigoUsuario) == false) // Se comprueba la existencia del usuario
                                                                    {
                                                                        // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                        i++;
                                                                        matrizErrores[i] = numLinea;
                                                                        numLinea++;
                                                                    }
                                                                    else
                                                                    {
                                                                        if(datos.comprobarFormatoFecha(cadenaFechaAlta) == false) // Se comprueba que el formato de la fecha es correcto
                                                                        {
                                                                            // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                            i++;
                                                                            matrizErrores[i] = numLinea;
                                                                            numLinea++;
                                                                        }
                                                                        else
                                                                        {
                                                                            Fecha fechaAlta = new Fecha(cadenaFechaAlta);
                                                                            if(fechaAlta.comprobarFechaValida() == true) // Se comprueba que la fecha existe en nuestro calendario
                                                                            {
                                                                                // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                                i++;
                                                                                matrizErrores[i] = numLinea;
                                                                                numLinea++;
                                                                            }
                                                                            else
                                                                            {
                                                                                if((!fechaAlta.esPosterior(fechaInicio)) && (!fechaAlta.esIgual(fechaInicio))) // Se comprueba que la fecha de mensaje es posterior a la de la conversaci�n
                                                                                {
                                                                                    // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                                    i++;
                                                                                    matrizErrores[i] = numLinea;
                                                                                    numLinea++;
                                                                                }
                                                                                else
                                                                                {
                                                                                    if(conversacion.obtenerMensaje(49) == null) // Se comprueba que el vector de mensajes no est� lleno
                                                                                    {
                                                                                        mensaje = new Mensaje(identificadorM, titulo, fechaAlta, codigoUsuario, texto); // Se crea el mensaje
                                                                                        conversacion.agnadirMensaje(mensaje); // Se a�ade el mensaje a la conversacion
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                        // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                                        i++;
                                                                                        matrizErrores[i] = numLinea;
                                                                                        System.out.println("Mensaje linea " + numLinea + " no a�adido por falta de espacio");
                                                                                    }
                                                                                    contadorMensajes = contadorMensajes + 1; // Se cuentan los mensajes con formato correcto
                                                                                    numLinea++;
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            else
                                                            {
                                                                // Se a�ade al vector de errores el n�mero de la linea fallida
                                                                i++;
                                                                matrizErrores[i] = numLinea;
                                                                numLinea++;
                                                            }
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    finWhile = true;
                                                }
                                            }
                                            else
                                            {
                                                // Si la linea es nula se desecha la conversaci�n, por no haberse encontrado una linea de fin
                                                System.out.println("Error desde linea " + tempNumLinea1 + " hasta el final del fichero " + obtenerNombreFicheroConversaciones());
                                                System.out.println("Se ha desechado la conversacion que no finaliza");
                                                finWhile = true;
                                                int aux = tempNumLinea1;
                                                for(int j = 0; j < (numLinea - tempNumLinea1); j++) // Se recorren las lineas err�neas
                                                {
                                                    // Se a�ade al vector de errores el n�mero de la linea fallida
                                                    i++;
                                                    matrizErrores[i] = aux;
                                                    aux++;
                                                    linea = fichero.leerLinea();
                                                }
                                            }
                                        }// Se cierra del while de lectura de mensajes
                                        if(contadorMensajes > 50)
                                        {
                                            // Los mensajes totales son los mensajes no a�adidos en cada conversaci�n por falta de espacio en el vector
                                            contadorMensajesTotales = contadorMensajesTotales + (contadorMensajes - 50);
                                        }
                                        contadorMensajes = 0; // Se reinicia la variable para la siguiente lectura de mensajes
                                        if(linea != null) 
                                        {
                                            if(mensajes[0] == null)
                                            {
                                                i++;
                                                matrizErrores[i] = numLinea; // Se a�ade el n�mero de la linea de fin al vector de errores porque al estar vac�a la conversaci�n no es correcta
                                                i++;
                                                matrizErrores[i] = tempNumLinea1; // Se a�ade el n�mero de la linea de conversaci�n al vector de errores porque al estar vac�a la conversaci�n no es correcta
                                                // Si la conversaci�n no tiene mensajes correctos queda desechada
                                                System.out.println("Error desde linea " + tempNumLinea1 + " a " + numLinea + " del fichero " + obtenerNombreFicheroConversaciones());
                                                System.out.println("Se ha desechado la conversacion sin mensajes correctos");
                                                contadorConversaciones = contadorConversaciones - 1; // Se le resta uno al contador de conversaciones por haber desechado esta conversaci�n
                                            }
                                            else
                                            {
                                                // La conversaci�n tiene el formato correcto
                                                if(comprobarEspacioMatriz("conversacion", -1) == false)
                                                {
                                                    // Si hay espacio en el vector se a�ade la conversaci�n
                                                    agnadirConversacion(conversacion);
                                                }
                                                else
                                                {
                                                    String temp;
                                                    FicheroLectura ficheroTemp = new FicheroLectura(_propiedadesNombreFicheros[1]); // Se abre otro fichero temporal
                                                    for(int k = tempNumLinea1; k <= numLinea; k++) // Se recorren las lineas de la conversaci�n que no ha sido guardada por no haber espacio
                                                    {
                                                        temp = ficheroTemp.leerLinea();
                                                        if(temp.length() != 0)
                                                        {
                                                            // Si no se trata de un intro se guarda el n�mero de la linea err�nea en la matriz de errores
                                                            i++;
                                                            matrizErrores[i] = k;
                                                        }
                                                    }
                                                    ficheroError.cerrarFichero(); // Se cierra el fichero temporal
                                                    System.out.println("Error desde linea " + tempNumLinea1 + " a " + numLinea + " del fichero " + obtenerNombreFicheroConversaciones());
                                                    System.out.println("Conversacion no a�adida por falta de espacio");
                                                }
                                                contadorConversaciones = contadorConversaciones + 1; // Se a�ade uno al contador de conversaciones
                                            }
                                        }
                                        numLinea++;
                                    }
                                }
                            }
                        } 
                    }
                    else
                    {
                        // Se a�ade al vector de errores el n�mero de la linea fallida
                        i++;
                        matrizErrores[i] = numLinea;
                        numLinea++;
                    }
                }
            }
            int cont1 = 0, cont2 = 0, temp = 0;
            for(cont1 = 1; cont1 < contadorLineas; cont1++) // Se ordena la matriz de errores de menor a mayor, sin tener en cuenta los ceros
            {
                for(cont2 = 0; cont2 < contadorLineas - 1; cont2++)
                {
                    if((matrizErrores[cont2] > matrizErrores[cont2+1]) && (matrizErrores[cont2+1] != 0))
                    {
                        temp = matrizErrores[cont2+1];
                        matrizErrores[cont2+1] = matrizErrores[cont2];
                        matrizErrores[cont2] = temp;
                    }
                }
            }
            String error;
            FicheroLectura ficheroMostrar;
            ficheroMostrar = new FicheroLectura(_propiedadesNombreFicheros[1]); // Se abre un fichero temporal para mostrar los errores
            int y = 0;
            for(int x = 1; x < matrizErrores.length; x++) // Se recorren las lineas del fichero
            {
               error = ficheroMostrar.leerLinea();
               if(x  == matrizErrores[y]) // Se comprueba que el n�mero de la linea le�da corresponde con una linea err�nea
               {
                   while(matrizErrores[y] == matrizErrores[y+1]) // Se comprueba que la linea err�nea no es repetida para no volver a mostrarla
                   {
                       y++;
                   }
                   if(error.length() != 0)
                   {
                       // Si la linea err�nea no es un intro se muestra
                       System.out.println("Error linea "+ matrizErrores[y] + " del fichero " + obtenerNombreFicheroConversaciones());
                       System.out.println("<" + error + ">");
                   }
                   y++;
               }
            }
            ficheroMostrar.cerrarFichero(); // Se cierra el fichero temporal
            if(contadorConversaciones > obtenerNumMaxConversaciones())
            {
                // Se muestra el n�mero de conversaciones no a�adidas por no haber espacio en el vector
                System.out.println("Se ha superado el numero maximo de conversaciones");
                System.out.println((contadorConversaciones - obtenerNumMaxConversaciones()) + " conversaciones no a�adidas");
                System.out.println("Las conversaciones no a�adidas y sus mensajes asociados quedaran invalidadas y borradas del fichero de datos");
            }
            if(contadorMensajesTotales > 0)
            {
                // Se muestra el n�mero de los mensajes no a�adidos de todas las conversaciones por no haber tenido espacio en el vector
                System.out.println("Se ha superado el numero maximo de mensajes en una o varias conversaciones");
                System.out.println(contadorMensajesTotales + " mensajes totales no a�adidos");
                System.out.println("Los mensajes no a�adidos quedaran invalidados y borrados de sus conversaciones asociadas respectivas y del fichero de datos");
            }
            fichero.cerrarFichero(); // Se cierra el fichero de conversaciones
        }
    }
}