
/**
 * En la clase Buscar se buscan los mensajes existentes en el foro que sean posteriores a una fecha determinada, y que contengan una cadena.
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Buscar
{
    Fecha _fecha;
    String _texto;
    
    /**
     * Se crea un nuevo Buscar
     */
    
    public Buscar()
    {
        System.out.println("Introduzca la fecha a partir de la cual se mostrar�n los mensajes encontrados:");
        Fecha fech = new Fecha();
        _fecha = fech;
        System.out.println("Si no se introduce una cadena de busqueda se procedera a mostrar todos los mensajes de las conversaciones");
        System.out.println("Introduzca la cadena a buscar:");
        Teclado text = new Teclado();
        _texto = text.leerLinea().trim();
    }
    
    /**
     * @return La Fecha
     */
    
    public Fecha obtenerFecha()
    {
        return _fecha;
    }
    
    /**
     * @return El Texto
     */
    
    public String obtenerTexto()
    {
        return _texto;
    }
    
    /**
     * Se obtienen los mensajes de todas las conversaciones del foro
     * @param conversacion Todas las conversaciones del foro
     * @param foro El propio foro
     * @return Vector que contiene todos los mensajes del foro
     */
    
    public Mensaje[] obtenerMensajes(Conversacion[] conversacion, Foro foro)
    {
        int i = 0, j= 0, k = 0, contador = 0;
        Mensaje matrizAuxiliar[]; // Se define un vector de mensajes que contendr� todos los mensajes del foro
        for(i = 0; i <= (foro.obtenerNumConversaciones() - 1); i++)
        {
            for(j = 0; j <= ((conversacion[i].obtenerNumMensajes()) - 1); j++)
            {
                contador = contador + 1; // Se cuentan los mensajes de todas las conversaciones 
            }
        }
        matrizAuxiliar = new Mensaje[contador]; // Se  crea la matriz con dimensi�n igual al n�mero de mensajes que hay en el foro
        // Se copian todos los mensajes del foro en el vector de mensajes
        for(i = 0; i <= (foro.obtenerNumConversaciones() - 1); i++)
        {
            for(j = 0; j <= ((conversacion[i].obtenerNumMensajes()) - 1); j++, k++)
            {
                matrizAuxiliar[k] = conversacion[i].obtenerMensaje(j);
            }
        }
        return matrizAuxiliar;
    }
    
    /**
     * Ordena los mensajes seg�n su fecha de alta
     * @param matrizAuxiliar Vector con todos los mensajes del foro
     * @return Vector con los mensajes ordenados por fechas
     */
    
    public Mensaje[] ordenarMensajes(Mensaje[] matrizAuxiliar)
    {
        int cont1 = 0, cont2 = 0, contador = matrizAuxiliar.length;
        Mensaje temp;
        // Se ordenan los mensajes por fechas
        for(cont1 = 1; cont1 < contador; cont1++)
        {
            for(cont2 = 0; cont2 < contador - 1; cont2++)
            {
                if((matrizAuxiliar[cont2].obtenerFechaAlta()).esPosterior((matrizAuxiliar[cont2+1].obtenerFechaAlta())))
                {
                    temp = matrizAuxiliar[cont2+1];
                    matrizAuxiliar[cont2+1] = matrizAuxiliar[cont2];
                    matrizAuxiliar[cont2] = temp;
                }
            }
        }
        return matrizAuxiliar;
    }

    /**
     * Se buscan los mensajes que cumplen los requisitos de b�squeda: que sean posteriores a la fecha introducida y
     * que contengan una cadena que tambi�n ha sido introducida
     * @param matrizAuxiliar Vector con los mensajes de todas las conversaciones ya ordenados
     * @param fecha Fecha para buscar los mensajes con fecha posterior a �sta
     * @param texto Cadena para buscar los mensajes que contengan esta cadena
     * @return Vector con los mensajes que cumplen los requisitos de b�squeda
     */
    
    public Mensaje[] buscarMensajes(Mensaje[] matrizAuxiliar, Fecha fecha, String texto)
    {
        int limiteInicial = 0;
        int limiteFinal = matrizAuxiliar.length -1;
        int tamagno = matrizAuxiliar.length;
        int mitad = 0;
        int posiFechaLimite = 0;
        boolean encontro = false;
        Mensaje aux[];
        if((matrizAuxiliar.length != 0) && (fecha.obtenerCadenaFecha() != null)) // Si hay mensajes, y la fecha ha sido introducida se buscan los mensajes
        {
            // Se buscan los mensajes con fecha posterior a la introducida
            while((limiteInicial <= limiteFinal) && (encontro == false))
            {
                mitad = (limiteInicial + limiteFinal) / 2;
                if(((matrizAuxiliar[mitad]).obtenerFechaAlta()).esPosterior(fecha))
                {
                    limiteFinal = mitad -1;
                }
                else
                {
                    if(!(((matrizAuxiliar[mitad]).obtenerFechaAlta()).esIgual(fecha)))
                    {
                        limiteInicial = mitad +1;
                    }
                    else
                    {
                        encontro = true;
                    }
                }
            }
            if(encontro == true)
            {
                posiFechaLimite = mitad;
            }
            else
            {
                if((matrizAuxiliar[mitad].obtenerFechaAlta().esPosterior(fecha)))
                {
                    posiFechaLimite = mitad; 
                }
                else
                {
                    posiFechaLimite = mitad + 1;
                }
            }
            aux = new Mensaje[tamagno - posiFechaLimite + 1];
            int x = posiFechaLimite;
            int y = 0;
            // Se buscan los mensajes que contengan la cadena introducida en su t�tulo o su texto
            Datos contieneCadenas = new Datos();
            while(x <= tamagno - 1)
            {
                if(
                    (contieneCadenas.contiene((matrizAuxiliar[x].obtenerTitulo()), texto)) ||
                    (contieneCadenas.contiene((matrizAuxiliar[x].obtenerTexto()), texto))
                  )
                {
                    aux[y] = matrizAuxiliar[x]; // Se a�ade una copia del mensaje encontrado en la matriz auxiliar
                }
                x = x + 1;
                y = y + 1;
            }
        }
        else
        {
            aux = new Mensaje[0]; // Si no encuentra mensajes, la matriz auxiliar queda vacia
        }
        return aux;
    }
    
    /**
     * Se muestran los mensajes que han sido encontrados
     * @param encontrados Vector con los mensajes que han sido encontrados en el foro seg�n los requisistos de b�squeda
     */
    
    public void mostrarBusqueda(Mensaje[] encontrados)
    {
        System.out.println("-------------------- BUSCADOR DE MENSAJES --------------------");
        if(_fecha.obtenerCadenaFecha() == null)  // Se comprueba que la fecha sea nula
        {
             System.out.println();
             System.out.println("Error en el formato de la fecha, deben ser valores numericos enteros y del formato dd/mm/aaaa, busqueda fallida");
        }
        else
        {
            System.out.println("Fecha limite: " + _fecha.obtenerCadenaFecha());
            System.out.println("Cadena a buscar: " + _texto);
            
        }
        int i = 0;
        if(encontrados.length != 0 && encontrados[0] != null)
        {
            // Si se han encontrado mensajes, se muestran
            while(encontrados[i] != null)
            {
                System.out.println();
                System.out.print(encontrados[i].obtenerTitulo() + "  ");
                System.out.print(encontrados[i].obtenerCodigoUsuario() + "       ");
                System.out.println(encontrados[i].obtenerFechaAlta().obtenerCadenaFecha());
                System.out.println(encontrados[i].obtenerTexto());
                if(((i + 1) % 5 == 0) && (i != 1))
                {
                    System.out.println();
                    System.out.println("** Mensajes mostrados: " + (i+1) + " de " + (encontrados.length-1) + " mensajes encontrados");
                    System.out.println("   Presione intro para continuar");
                    Teclado intro = new Teclado();
                    String pausa;
                    pausa = intro.leerLinea();
                }
                i++;
            }
        }
        else
        {
            System.out.println();
            System.out.println("Ningun mensaje encontrado");
        }
        System.out.println();
        System.out.println("--------------------------------------------------------------");
    }
}