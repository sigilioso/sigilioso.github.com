
/**
 * La clase conversaci�n crea nuevas conversaciones y gestiona los mensajes que contiene
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Conversacion
{
    Mensaje _mensaje[];
    String _tema;
    Fecha _fechaInicio;
    char _identificador;
    final String _fin = "-FIN-";
    
    /**
     * Se crea una nueva conversaci�n desde el men�
     * @param foro El foro que contiene las conversaciones
     */
    
    public Conversacion(Foro foro)
    {
        if(foro.comprobarEspacioMatriz("conversacion", -1) == false) // Se comprueba que hay espacio en el vector
        {
            _identificador = 'C';
            _mensaje = new Mensaje[50];
            String codigo, contrasegna, titulo, texto;
            char identificadorM = 'M';
            boolean exito = false, existeConv = true;
            Datos datos = new Datos();
            Teclado teclas = new Teclado();
            System.out.println("-------------------- ALTA DE CONVERSACION --------------------");
            System.out.println("Introduzca su codigo de usuario: ");
            codigo = teclas.leerLinea();
            System.out.println("Introduzca su contrase�a:");
            contrasegna = teclas.leerLinea();
            exito = datos.comprobarUsuario(foro, codigo, contrasegna); // Se comprueba la existencia y se valida al usuario
            if(exito != false)
            {
                String tematmp;
                System.out.println("CONVERSACION");
                System.out.println("Introduzca el tema de la conversacion");
                tematmp = teclas.leerLinea();
                existeConv = datos.comprobarExisteConversacion(foro, tematmp); // Se comprueba la existencia de la conversaci�n
                if(existeConv)
                {
                    System.out.println();
                    System.out.println("Ya existe en el foro una conversacion con ese tema");
                }
                else
                {
                    _tema = tematmp.trim();
                    System.out.println("Introduzca la fecha de inicio de la conversacion");
                    _fechaInicio = new Fecha();
                    if(_fechaInicio.obtenerCadenaFecha() != null) // Se comprueba que existe una fecha
                    {
                        if((_tema.length() < 1) || (_fechaInicio.comprobarFechaValida() == true)) // Se comprueba que no faltan datos y que la fecha existe en nuestro calendario
                        {
                            System.out.println("Error en los datos introducidos, conversacion no a�adida");
                        }
                        else
                        {
                            System.out.println("MENSAJE");
                            System.out.println("Introduzca el primer mensaje de la conversacion");
                            System.out.println("Introduzca el titulo del mensaje");
                            titulo = teclas.leerLinea().trim();
                            System.out.println("Introduzca el cuerpo del mensaje");
                            texto = teclas.leerLinea().trim();
                            if((titulo.length() == 0) || (texto.length() == 0)) // Se comprueba que no faltan datos
                            {
                                System.out.println("Mensaje introducido no valido");
                            }
                            else
                            {
                                _mensaje[0] = new Mensaje(identificadorM, titulo, _fechaInicio, codigo, texto);
                                System.out.println("Conversacion y primer mensaje a�adidos");
                                foro.agnadirConversacion(this); // Se a�ade la conversaci�n al vector
                            }
                        }
                    }
                    else
                    {
                        System.out.println("Error en el formato de la fecha, deben ser valores numericos enteros y del formato dd/mm/aaaa, conversacion no a�adida");
                    }
                }
            }
        }
        else
        {
            System.out.println("Se ha superado el numero maximo de conversaciones");
            System.out.println("Conversacion no a�adida");
        }
    }
    
    /**
     * Se crea una nueva conversaci�n desde el fichero
     * @param mensaje Vector con mensajes
     * @param tema El tema de la conversaci�n
     * @param fechaInicio La fecha de inicio de la conversaci�n
     * @param identificador El identificador de la conversaci�n
     * @param foro El foro que contiene las conversaciones
     */
    
    public Conversacion(Mensaje mensaje[], String tema, Fecha fechaInicio, char identificador, Foro foro)
    {
        _mensaje = new Mensaje[50];
        _mensaje = mensaje;
        _tema = tema;
        _fechaInicio = fechaInicio;
        _identificador = identificador;
    }
    
    /**
     * @return El identificador
     */
    
    public char obtenerIdentificador()
    {
        return _identificador;
    }
    
    /**
     * @param indice La posici�n del mensaje en el vector
     * @return El mensaje de dicha posici�n
     */
    
    public Mensaje obtenerMensaje(int indice)
    {
        return _mensaje[indice];
    }
    
    /**
     * @return El vector con todos los mensajes
     */
    
    public Mensaje[] obtenerTodosMensajes()
    {
        return _mensaje;
    }
    
    /**
     * @return El tema
     */
    
    public String obtenerTema()
    {
        return _tema;
    }
    
    /**
     * @return La fecha de inicio
     */
    
    public Fecha obtenerFechaInicio()
    {
        return _fechaInicio;
    }
    
    /**
     * @return La cadena de la fecha de inicio
     */
    
    public String obtenerCadenaFechaInicio()
    {
        return _fechaInicio.obtenerCadenaFecha();
    }
    
    /**
     * @return El numero de mensajes que hay dentro del vector
     */ 
    
    public int obtenerNumMensajes()
    {
        int i = 0, contador = 0;
        if(_mensaje[49] == null) // Se comprueba que el vector no esta lleno
        {
            while(_mensaje[i] != null)
            {
                contador = contador + 1;
                i = i + 1;
            }
        }
        else // Si est� lleno se le da el el tama�o del vector 
        {
            contador = _mensaje.length;
        }
        return contador;
    }
    
    /**
     * @return El fin
     */
    
    public String obtenerFin()
    {
        return _fin;
    }
    
    /**
     * Se a�ade un mensaje al vector
     */
    
    public void agnadirMensaje(Mensaje mensaje)
    {
        int i=0;
        if(_mensaje[49] == null) // Se comprueba que el vector no esta lleno
        {
            while(_mensaje[i] != null)
            {
                i++;
            }
            _mensaje[i] = mensaje;
        }
    }
    
    /**
     * Se ordenan los mensajes de la conversacion
     */
    
    public void ordenarMensajes()
    {
        int cont1 = 0, cont2 = 0, contador = obtenerNumMensajes();
        Mensaje temp;
        for(cont1 = 1; cont1 < contador; cont1++)
        {
            for(cont2 = 0; cont2 < contador - 1; cont2++)
            {
                if((_mensaje[cont2].obtenerFechaAlta()).esPosterior((_mensaje[cont2+1].obtenerFechaAlta())))
                {
                    temp = _mensaje[cont2+1];
                    _mensaje[cont2+1] = _mensaje[cont2];
                    _mensaje[cont2] = temp;
                }
            }
        }
    }
}