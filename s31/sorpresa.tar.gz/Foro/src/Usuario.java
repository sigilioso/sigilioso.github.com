
/**
 * La clase Usuario crea usuarios tanto desde el men� como desde el fichero
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Usuario
{
    String _codigo;
    String _contrasegna;
    String _apodo;

    /**
     * Se crea un nuevo usuario desde el fichero
     * @param codigo El codigo del usuario
     * @param contrasegna La contrase�a del usuario
     * @param apodo El apodo del usuario
     * @param foro El foro que contiene los usuarios
     */
    
    public Usuario(String codigo, String contrasegna, String apodo, Foro foro)
    {
        if(foro.comprobarEspacioMatriz("usuario", -1) == false) // Se comprueba que hay espacio en el vector de usuarios
        {
            _codigo = codigo;
            _contrasegna = contrasegna;
            _apodo = apodo;
        }
    }

    /**
     * Se crea un nuevo usuario desde el men�
     * @param foro El foro que contiene los usuarios
     */
    
    public Usuario(Foro foro)
    {
        if(foro.comprobarEspacioMatriz("usuario", -1) == false) // Se comprueba que hay espacio en el vector de usuarios
        {
            System.out.println("-------------------- ALTA DE USUARIO --------------------");
            Teclado recogerDatos = new Teclado();
            System.out.println("Introduzca el c�digo de usuario: ");
            _codigo = recogerDatos.leerLinea().trim();
            System.out.println("Introduzca la contrase�a de usuario: ");
            _contrasegna = recogerDatos.leerLinea().trim();
            System.out.println("Introduzca el apodo de usuario: ");
            _apodo = recogerDatos.leerLinea().trim();
            Datos datos = new Datos();
            if(datos.comprobarUsuario(foro, _codigo) == true) // Se comprueba la existencia del usuario
            {
                System.out.println("Error, el usuario ya existe en el foro");
            }
            else if((_codigo.length() < 1) || (_contrasegna.length() < 1) || (_apodo.length() < 1)) // Se comprueba que no falta ning�n dato
            {
                System.out.println("Error en los datos introducidos, usuario no a�adido");
            }
            else
            {
                foro.agnadirUsuario(this); // Se a�ade el usuario al vector
                System.out.println("Usuario a�adido");
            }
        }
        else
        {
            System.out.println("Se ha superado el numero maximo de usuarios");
            System.out.println("Usuario no a�adido");
        }
    }
    
    /**
     * @return El codigo
     */
    
    public String obtenerCodigo()
    {
        return _codigo;
    }
    
    /**
     * @return La contrase�a
     */
    
    public String obtenerContrasegna()
    {
        return _contrasegna;
    }
    
    /**
     * @return El apodo
     */
    
    public String obtenerApodo()
    {
        return _apodo;
    }
    
    /**
     * El m�todo modificarContrasegna modifica la contrase�a de un usario
     */
    
    public void modificarContrasegna()
    {
        String nuevaContrasegna;
        boolean salida = false;
        Teclado datos = new Teclado();
        do 
        {
            System.out.println("Introduzca la nueva contrase�a: ");
            nuevaContrasegna = datos.leerLinea();
            System.out.println("Confirme la nueva contrase�a: "); // Se le pide al usuario confirmaci�n de la contrase�a nueva
            if((datos.leerLinea()).compareTo(nuevaContrasegna) == 0)
            {
                _contrasegna = nuevaContrasegna;
                salida = true;
            }
            else
                System.out.println("No coinciden la nueva contrase�a y su confirmaci�n");
        }
        while(salida == false);
        System.out.println("Contrase�a cambiada satisfactoriamente!");
    }
    
    /**
     * El m�todo modificarApodo cambia el apodo del usuario 
     */
    
    public void modificarApodo()
    {
        Teclado datos = new Teclado();
        System.out.println("Introduzca el nuevo apodo: ");
        _apodo = datos.leerLinea();
        System.out.println("Apodo cambiado");
    }
}