
/**
 * La clase Fecha construye Fechas a partir de las cadenas le�das y compara dos fechas
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class Fecha
{
    int _dia, _mes, _agno;
    String _fecha; //Cadena con la fecha para su escritura en fichero

    /**
     * Se crea una nueva Fecha
     */
    
    public Fecha()
    {
        String fecha;
        boolean comprobacion = false;
        Datos recogerDatos = new Datos();
        fecha = recogerDatos.recogerFecha(); // Se recoge la fecha a trav�s del teclado
        comprobacion = recogerDatos.comprobarFormatoFecha(fecha); // se comprueba si la fecha es correcta
        if(comprobacion != false)
        {
            //Si la fecha es correcta se da valor a los atributos
            _dia = Integer.parseInt(fecha.substring(0, 2));
            _mes = Integer.parseInt(fecha.substring(3, 5));
            _agno = Integer.parseInt(fecha.substring(6));
            _fecha = fecha;
        }
    }
    
    /**
     * Se crea una nueva Fecha
     * @param cadenaFecha Cadena con el formato correcto de la fecha
     */
    
    public Fecha(String cadenaFecha)
    {
        _dia = Integer.parseInt(cadenaFecha.substring(0, 2));
        _mes = Integer.parseInt(cadenaFecha.substring(3, 5));
        _agno = Integer.parseInt(cadenaFecha.substring(6));
        _fecha = cadenaFecha;
    }

    /**
    * @return El valor del atributo _dia
    */

    public int obtenerDia()
    {
        return _dia;
    }

    /**
    * @return El valor del atributo _mes
    */

    public int obtenerMes()
    {
        return _mes;
    }

    /**
    * @return El valor del atributo _a�o
    */

    public int obtenerAgno()
    {
        return _agno;
    }
    
     /**
     * @return La cadena correspondiente a la fecha
     */
    
    public String obtenerCadenaFecha()
    {
        return _fecha;
    }
    
    /**
    * Comprueba que la Fecha es v�lida en nuestro calendario
    * @return True si la fecha no es v�lida
    */

    public boolean comprobarFechaValida()
    {
        boolean fallo=false, bisiesto=false;
        if((((_agno % 4) == 0) && ((_agno % 100) != 0)) || ((_agno % 400) == 0)) // Se comprueba que el a�o sea bisiesto
        {
            bisiesto = true;
        }
        // Se comprueba que los d�as y meses son valores v�lidos para nuestro calendario
        if(_mes >= 1 && _mes <= 12)
        {
            if(_dia >= 1 && _dia <= 31)
            {
                switch(_mes) // Se comprueba que el d�a introducido no sea mayor que el �ltimo d�a del mes correspondiente.
                {
                    case 2:
                    {
                        if(_dia <= 28)
                        {
                            fallo=false;
                        }
                        else
                        {
                            if(bisiesto == true && _dia == 29)
                            {
                                fallo = false;
                            }
                            else
                            {
                                fallo=true;
                                System.out.println("El dia introducido no concuerda con el mes");
                            }
                        }
                    }
                    break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                    {
                        if(_dia <= 30)
                        {
                            fallo=false;
                        }
                        else
                        {
                            fallo=true;
                            System.out.println("El dia introducido no concuerda con el mes");
                        }
                    }
                    break;
                    default:
                    {
                        if(_dia <= 31)
                        {
                            fallo=false;
                        }
                        else
                        {
                            fallo=true;
                            System.out.println("El dia introducido no concuerda con el mes");
                        }
                    }
                }
            }
            else
            {
                fallo=true;
                System.out.println("El dia es incorrecto");
            }
        }
        else
        {
            fallo=true;
            System.out.println("El mes es incorrecto");
        }
        return fallo;
    }
    
    /**
     * Compara que una fecha es posterior a otra
     * @param otraFecha Otra fecha
     * @return True si la fecha es posterior a la que se le pasa por par�metro
     */
    
    public boolean esPosterior(Fecha otraFecha)
    {
        boolean ret = false;
        if(_agno > otraFecha.obtenerAgno())
        {
            ret = true;
        }
        else
        {
            if(_agno < otraFecha.obtenerAgno())
            {
                ret = false;
            }
            if(_agno == otraFecha.obtenerAgno())
            {
                if(_mes > otraFecha.obtenerMes())
                {
                    ret = true;
                }
                else
                {
                    if(_mes < otraFecha.obtenerMes())
                    {
                        ret = false;
                    }
                    if(_mes == otraFecha.obtenerMes())
                    {
                        if(_dia > otraFecha.obtenerDia())
                        {
                            ret = true;
                        }
                        else
                        {
                            ret = false;
                        }
                    }
                }
            }
        }
        return ret;
    }
    
    /**
     * Compara que una fecha es igual a otra
     * @param fecha Otra fecha
     * @return True si la fecha es igual a la que se le pasa por par�metro
     */
    
    public boolean esIgual(Fecha fecha)
    {
        boolean igual = false;
        if(
            (_dia == fecha.obtenerDia()) &&
            (_mes == fecha.obtenerMes()) &&
            (_agno == fecha.obtenerAgno())
          )
        {
            igual = true;
        }
        return igual;
    }
}