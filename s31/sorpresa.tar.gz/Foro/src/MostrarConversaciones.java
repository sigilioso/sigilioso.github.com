
/**
 * La clase mostrar conversaciones contiene los m�todos necesarios para mostrar las conversaciones contenidas en el foro ordenadas
 * seg�n la fecha y el n�mero de mensajes 
 * @author Sergio Gil Bl�zquez
 * @author Christian Felipe �lvarez
 */

public class MostrarConversaciones
{
    Foro _foro;

    /**
     * Se crea un nuevo Mostrar conversaciones
     * @param foro Foro del que se muestran las conversaciones
     */
    
    public MostrarConversaciones(Foro foro)
    {
        _foro = foro;
    }
    
    /**
     * Ordena las conversaciones seg�n la fecha y el n�mero de mensajes que contienen
     * @param conversaciones Vector con las conversaciones del foro
     * @return Vector con las conversaciones ya ordenadas
     */
    
    public Conversacion[] ordenarConversaciones(Conversacion[] conversaciones) 
    {
        int cont1 = 0, cont2 = 0;
        int tamagno = _foro.obtenerNumConversaciones();
        Conversacion temp;
        for(cont1 = 1; cont1 < tamagno; cont1++) // Se ordenan seg�n la fecha
        {
            for(cont2 = 0; cont2 < tamagno - 1; cont2++)
            {
                if( (conversaciones[cont2].obtenerFechaInicio() ).esPosterior( (conversaciones[cont2+1].obtenerFechaInicio()) ) )
                {
                    temp = conversaciones[cont2];
                    conversaciones[cont2] = conversaciones[cont2+1];
                    conversaciones[cont2+1] = temp;
                }
            }
        }
        for(cont1 = 1; cont1 < tamagno; cont1++)
        {
            for(cont2 = 0; cont2 < tamagno -1; cont2++) // Las conversaciones ordenadas por fecha se ordenan seg�n el n�mero de mensajes
            {
                if( ( (conversaciones[cont2].obtenerFechaInicio() ).esIgual((conversaciones[cont2+1].obtenerFechaInicio())) ) &&
                    ( (conversaciones[cont2].obtenerNumMensajes()) > (conversaciones[cont2+1].obtenerNumMensajes()) )  )
                {
                    temp = conversaciones[cont2];
                    conversaciones[cont2] = conversaciones[cont2+1];
                    conversaciones[cont2+1] = temp;
                }
            }
        }
        for(int i = 0; i < tamagno; i++) // Se ordenan los mensajes de cada conversaci�n seg�n su fecha
        {
            Mensaje tmp;
            for(cont1 = 1; cont1 < conversaciones[i].obtenerNumMensajes(); cont1++)
            {
                conversaciones[i].ordenarMensajes();
            }
        }
        return conversaciones;   
    }
    
    /**
     * Se muestran las conversaciones previamente ordenadas
     * @param conversa Vector de conversaciones que contiene las conversaciones del foro ordenadas
     */
    
    public void mostrarConversaciones(Conversacion[] conversa)
    {
        System.out. println("-------------------- CONSULTA DE CONVERSACIONES --------------------");
        int i = 0, j = 0;
        if(conversa[0] != null)
        {
            //Si hay conversaciones, se muestran
            while((i < _foro.obtenerNumMaxConversaciones()) && (conversa[i] != null))
            {
                j = 0;
                System.out.println();
                System.out.println("Titulo: " + conversa[i].obtenerTema() + "     Fecha inicio: " + conversa[i].obtenerCadenaFechaInicio() );
                System.out.println();
                while((j < 50) && (conversa[i].obtenerMensaje(j) != null)) // Se muestran los mensajes de cada conversaci�n
                {
                    System.out.println("      " + conversa[i].obtenerMensaje(j).obtenerTitulo() + "  (" + conversa[i].obtenerMensaje(j).obtenerCodigoUsuario() + ")     " + conversa[i].obtenerMensaje(j).obtenerCadenaFechaAlta() );
                    System.out.println("      " + conversa[i].obtenerMensaje(j).obtenerTexto());
                    System.out.println();
                    j++;
                }
                i++;
                // Se hace una pausa tras mostrar cada coversaci�n, esperando a que el usuario presione intro
                System.out.println();
                System.out.println("** Conversacion mostrada: " + i + " de " + _foro.obtenerNumConversaciones());
                System.out.println("   Presione intro para continuar");
                Teclado intro = new Teclado();
                String pausa;
                pausa = intro.leerLinea();
            }
        }
        else
        {
            System.out.println();
            System.out.println("No existen conversaciones");
        }
        System.out.println();
        System.out.println("--------------------------------------------------------------------");
    }
}